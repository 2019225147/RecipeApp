// components/ImagePickerField.tsx
import * as ImageManipulator from 'expo-image-manipulator';
import * as ImagePicker from 'expo-image-picker';
import React, { useState } from 'react';
import { ActivityIndicator, Image, Pressable, Text, View } from 'react-native';

type Props = {
  value?: string | null;
  onChange: (uri: string | null) => void;
  label?: string;
};

export default function ImagePickerField({ value, onChange, label }: Props) {
  const [busy, setBusy] = useState(false);

  const pick = async () => {
    const { status } = await ImagePicker.requestMediaLibraryPermissionsAsync();
    if (status !== 'granted') {
      alert('사진 라이브러리 권한이 필요합니다.');
      return;
    }
    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.Images,
      allowsEditing: true,
      aspect: [4, 3],
      quality: 0.9,
    });
    if (!result.canceled) {
      setBusy(true);
      const m = await ImageManipulator.manipulateAsync(
        result.assets[0].uri,
        [{ resize: { width: 1280 } }],
        { compress: 0.8, format: ImageManipulator.SaveFormat.JPEG }
      );
      onChange(m.uri);
      setBusy(false);
    }
  };

  return (
    <View style={{ gap: 8 }}>
      {label ? <Text style={{ fontWeight: '600' }}>{label}</Text> : null}
      <Pressable
        onPress={pick}
        style={{
          height: 180,
          borderRadius: 12,
          backgroundColor: '#f3f4f6',
          alignItems: 'center',
          justifyContent: 'center',
          overflow: 'hidden',
        }}
      >
        {busy ? (
          <ActivityIndicator />
        ) : value ? (
          <Image source={{ uri: value }} style={{ width: '100%', height: '100%' }} />
        ) : (
          <Text>이미지 선택</Text>
        )}
      </Pressable>
    </View>
  );
}
