// components/AppHeader.tsx
import { useRouter } from "expo-router";
import React from "react";
import { Pressable, StyleSheet, Text, View } from "react-native";

type Props = {
  title: string;
  showBack?: boolean;              // 홈에서는 false, 나머지는 true
  rightSlot?: React.ReactNode;     // 오른쪽에 버튼(필터, 추가 등) 넣고 싶을 때
};

export default function AppHeader({ title, showBack = true, rightSlot }: Props) {
  const router = useRouter();

  return (
    <View style={styles.container}>
      {/* 왼쪽: 뒤로가기 */}
      <View style={styles.left}>
        {showBack && (
          <Pressable
            onPress={() => router.back()}
            style={styles.backBtn}
          >
            <Text style={styles.backText}>←</Text>
          </Pressable>
        )}
      </View>

      {/* 가운데: 제목 */}
      <View style={styles.center}>
        <Text numberOfLines={1} style={styles.title}>{title}</Text>
      </View>

      {/* 오른쪽: 옵션 영역 */}
      <View style={styles.right}>{rightSlot}</View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    height: 52,
    flexDirection: "row",
    alignItems: "center",
    paddingHorizontal: 12,
    backgroundColor: "#fff",
    borderBottomWidth: 1,
    borderBottomColor: "#E5E7EB",
  },
  left: { width: 40 },
  backBtn: {
    paddingHorizontal: 8,
    paddingVertical: 6,
  },
  backText: { fontSize: 18, fontWeight: "800" },
  center: { flex: 1, alignItems: "center" },
  title: { fontSize: 16, fontWeight: "800" },
  right: { width: 40, alignItems: "flex-end" },
});
