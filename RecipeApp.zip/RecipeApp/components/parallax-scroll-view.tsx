// components/parallax-scroll-view.tsx
import React, { ReactNode } from "react";
import { ImageBackground, ScrollView, StyleSheet, View } from "react-native";

type Props = {
  headerImage?: string;
  height?: number;
  children: ReactNode;
};

export default function ParallaxScrollView({ headerImage, height = 180, children }: Props) {
  return (
    <ScrollView contentContainerStyle={styles.container}>
      {headerImage ? (
        <ImageBackground
          source={{ uri: headerImage }}
          style={[styles.header, { height }]}
          imageStyle={{ opacity: 0.9 }}
        />
      ) : (
        <View style={[styles.header, styles.placeholder, { height }]} />
      )}

      <View style={{ height: 12 }} />
      <View style={styles.content}>{children}</View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { padding: 16 },
  header: {
    width: "100%",
    borderRadius: 12,
    overflow: "hidden",
  },
  placeholder: {
    backgroundColor: "#f3f4f6",
    borderWidth: StyleSheet.hairlineWidth,
    borderColor: "#e5e7eb",
  },
  content: {
    width: "100%",
  },
});
