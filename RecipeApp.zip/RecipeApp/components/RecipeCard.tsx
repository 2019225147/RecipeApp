// components/RecipeCard.tsx
import { Ionicons } from "@expo/vector-icons";
import { useRouter } from "expo-router";
import React from "react";
import {
  Image,
  Pressable,
  StyleSheet,
  Text,
  View,
} from "react-native";
import { useFavorites } from "../hooks/useFavorites"; // ✅ named import

export type RecipeCardBadge = {
  text: string;
  tone: "dark" | "light";
};

type Props = {
  item: any; // id, title, imageUrl, image, time, difficulty 등 포함
  size?: number; // 정사각형 카드 한 변 길이 (/recipes, /favorites 등에서 넘겨줌)
  topLeftBadges?: RecipeCardBadge[];
  onPress?: () => void;
};

export default function RecipeCard({
  item,
  size = 160,
  topLeftBadges = [],
  onPress,
}: Props) {
  const router = useRouter();
  const { isFavorite, toggleFavorite } = useFavorites();

  const imageUri = item.imageUrl || item.image || "";
  const fav = item.id ? isFavorite(item.id) : false;

  const handlePress = () => {
    if (onPress) {
      onPress();
      return;
    }
    if (item.id) {
      router.push(`/recipes/${item.id}`);
    }
  };

  const handleToggleFavorite = () => {
    if (!item.id) return;
    toggleFavorite(item.id);
  };

  return (
    <Pressable
      onPress={handlePress}
      style={({ pressed }) => [
        styles.card,
        { width: size, minHeight: size + 60 },
        pressed && styles.cardPressed,
      ]}
    >
      <View style={[styles.imageWrapper, { height: size }]}>
        {imageUri ? (
          <Image source={{ uri: imageUri }} style={styles.image} />
        ) : (
          <View style={styles.imagePlaceholder}>
            <Text style={styles.imagePlaceholderText}>
              이미지 없음
            </Text>
          </View>
        )}

        {/* 좌상단 뱃지들 (조리시간, 난이도 등) */}
        {topLeftBadges.length > 0 && (
          <View style={styles.badgesContainer}>
            {topLeftBadges.map((b, idx) => (
              <View
                key={`${b.text}-${idx}`}
                style={[
                  styles.badge,
                  b.tone === "dark"
                    ? styles.badgeDark
                    : styles.badgeLight,
                ]}
              >
                <Text
                  style={[
                    styles.badgeText,
                    b.tone === "dark"
                      ? styles.badgeTextDark
                      : styles.badgeTextLight,
                  ]}
                  numberOfLines={1}
                >
                  {b.text}
                </Text>
              </View>
            ))}
          </View>
        )}

        {/* 🔥 우상단 즐겨찾기 토글 */}
        {item.id && (
          <Pressable
            onPress={(e) => {
              e.stopPropagation();
              handleToggleFavorite();
            }}
            style={styles.favoriteButton}
          >
            <Ionicons
              name={fav ? "heart" : "heart-outline"}
              size={18}
              color={fav ? "#f97316" : "#f9fafb"}
            />
          </Pressable>
        )}
      </View>

      {/* 텍스트 영역 */}
      <View style={styles.content}>
        <Text
          style={styles.title}
          numberOfLines={2}
          ellipsizeMode="tail"
        >
          {item.title ?? "제목 없는 레시피"}
        </Text>

        {!!item.description && (
          <Text
            style={styles.description}
            numberOfLines={2}
            ellipsizeMode="tail"
          >
            {item.description}
          </Text>
        )}

        {/* 하단 메타 정보 (시간 / 난이도 등 간단 표시) */}
        <View style={styles.metaRow}>
          {typeof item.time === "number" && (
            <Text style={styles.metaText}>⏱ {item.time}분</Text>
          )}
          {!!item.difficulty && (
            <Text style={styles.metaText}> · {item.difficulty}</Text>
          )}
        </View>
      </View>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  card: {
    borderRadius: 16,
    backgroundColor: "#ffffff",
    overflow: "hidden",
    elevation: 2,
    shadowColor: "#000",
    shadowOpacity: 0.08,
    shadowRadius: 6,
    shadowOffset: { width: 0, height: 2 },
    marginBottom: 10,
  },
  cardPressed: {
    opacity: 0.9,
    transform: [{ scale: 0.98 }],
  },

  imageWrapper: {
    width: "100%",
    borderTopLeftRadius: 16,
    borderTopRightRadius: 16,
    overflow: "hidden",
    backgroundColor: "#e5e7eb",
  },
  image: {
    width: "100%",
    height: "100%",
    resizeMode: "cover",
  },
  imagePlaceholder: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
  },
  imagePlaceholderText: {
    fontSize: 12,
    color: "#6b7280",
  },

  badgesContainer: {
    position: "absolute",
    top: 6,
    left: 6,
    flexDirection: "row",
    flexWrap: "wrap",
    gap: 4,
  },

  // ⭐ 즐겨찾기 버튼 스타일
  favoriteButton: {
    position: "absolute",
    top: 6,
    right: 6,
    paddingHorizontal: 6,
    paddingVertical: 4,
    borderRadius: 999,
    backgroundColor: "rgba(15,23,42,0.7)",
  },

  badge: {
    paddingHorizontal: 6,
    paddingVertical: 2,
    borderRadius: 999,
  },
  badgeDark: {
    backgroundColor: "rgba(17,24,39,0.88)",
  },
  badgeLight: {
    backgroundColor: "rgba(243,244,246,0.9)",
  },
  badgeText: {
    fontSize: 10,
  },
  badgeTextDark: {
    color: "#f9fafb",
    fontWeight: "500",
  },
  badgeTextLight: {
    color: "#111827",
  },

  content: {
    paddingHorizontal: 10,
    paddingVertical: 8,
    minHeight: 60, // 텍스트 두 줄 들어갈 여유
  },
  title: {
    fontSize: 13,
    lineHeight: 18,
    fontWeight: "700",
    color: "#111827",
  },
  description: {
    marginTop: 4,
    fontSize: 11,
    lineHeight: 15,
    color: "#6b7280",
  },
  metaRow: {
    flexDirection: "row",
    alignItems: "center",
    marginTop: 6,
  },
  metaText: {
    fontSize: 10,
    color: "#6b7280",
    marginRight: 4,
  },
});
