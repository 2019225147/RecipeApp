// components/ui/collapsible.tsx
import React, { ReactNode, useState } from "react";
import { Pressable, StyleSheet, Text, View } from "react-native";

type CollapsibleProps = {
  title: string;
  initiallyOpen?: boolean;
  children: ReactNode;
};

export default function Collapsible({ title, initiallyOpen = false, children }: CollapsibleProps) {
  const [open, setOpen] = useState(initiallyOpen);

  return (
    <View style={styles.wrap}>
      <Pressable
        onPress={() => setOpen((v) => !v)}
        style={({ pressed }) => [styles.header, pressed && { opacity: 0.8 }]}
      >
        <Text style={styles.title}>{open ? "▾ " : "▸ "}{title}</Text>
      </Pressable>

      {open && (
        <>
          <View style={{ height: 8 }} />
          <View style={styles.body}>{children}</View>
        </>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  wrap: {
    borderWidth: StyleSheet.hairlineWidth,
    borderColor: "#e5e7eb",
    borderRadius: 10,
    backgroundColor: "#fff",
    padding: 12,
  },
  header: {
    paddingVertical: 4,
  },
  title: { fontSize: 16, fontWeight: "700" },
  body: {},
});
