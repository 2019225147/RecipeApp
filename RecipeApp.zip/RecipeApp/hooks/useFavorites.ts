// hooks/useFavorites.ts
import { ensureAnonLogin } from "@/lib/firebase";
import {
  subscribeFavorites,
  toggleFavorite as toggleFavoriteService,
} from "@/services/favorites";
import { useEffect, useState } from "react";

/**
 * 즐겨찾기 관리 훅
 * - ids: 즐겨찾기된 recipeId 목록
 * - isFavorite(id): 해당 레시피가 즐겨찾기인지 여부
 * - toggleFavorite(id): 즐겨찾기 토글
 */
export function useFavorites() {
  const [ids, setIds] = useState<string[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<unknown>(null);

  useEffect(() => {
    let alive = true;

    (async () => {
      try {
        // 익명 로그인 보장
        await ensureAnonLogin();

        // Firestore favorites 구독
        const unsub = await subscribeFavorites(
          (next) => {
            if (!alive) return;
            setIds(next);
          },
          (e) => {
            if (!alive) return;
            setError(e);
          }
        );

        if (alive) setLoading(false);

        // cleanup 함수
        return () => unsub?.();
      } catch (e) {
        if (alive) {
          setError(e);
          setLoading(false);
        }
      }
    })();

    return () => {
      alive = false;
    };
  }, []);

  const isFavorite = (id: string) => ids.includes(id);

  const toggleFavorite = async (idOrRecipe: string | { id: string }) => {
    try {
      const id =
        typeof idOrRecipe === "string" ? idOrRecipe : idOrRecipe.id;
      await toggleFavoriteService(id);
    } catch (e) {
      setError(e);
    }
  };

  return { ids, loading, error, isFavorite, toggleFavorite };
}
