// hooks/useRecipes.ts
import { auth, db } from '@/lib/firebase';
import { collection, getDocs, orderBy, query } from 'firebase/firestore';
import { useEffect, useState } from 'react';

export type RecipeListItem = {
  id: string;
  title: string;
  image?: string;
  time?: number;
  difficulty?: string;
  tags?: string[];
  createdAt?: any;
};

export function useRecipes() {
  const [items, setItems] = useState<RecipeListItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<unknown>(null);

  useEffect(() => {
    (async () => {
      try {
        setLoading(true);
        const q = query(collection(db, 'recipes'), orderBy('createdAt', 'desc'));
        const snaps = await getDocs(q);
        const list: RecipeListItem[] = snaps.docs.map((d) => ({ id: d.id, ...(d.data() as any) }));
        setItems(list);
      } catch (e) {
        setError(e);
      } finally {
        setLoading(false);
      }
    })();
  }, []);

  return { items, loading, error };
}

export function useUserFavoritesIds() {
  const uid = auth.currentUser?.uid ?? null;
  const [ids, setIds] = useState<string[]>([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (!uid) return; // ✅ uid 없으면 접근 금지
    (async () => {
      setLoading(true);
      try {
        const snaps = await getDocs(collection(db, 'users', uid, 'favorites'));
        setIds(snaps.docs.map((d) => d.id));
      } finally {
        setLoading(false);
      }
    })();
  }, [uid]);

  return { ids, loading, has: (id: string) => ids.includes(id) };
}
