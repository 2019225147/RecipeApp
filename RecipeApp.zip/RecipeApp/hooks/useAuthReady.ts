// hooks/useAuthReady.ts
import { auth } from '@/lib/firebase';
import { onAuthStateChanged } from 'firebase/auth';
import { useEffect, useState } from 'react';

export function useAuthReady() {
  const [ready, setReady] = useState(false);
  useEffect(() => {
    const off = onAuthStateChanged(auth, () => setReady(true));
    return () => off();
  }, []);
  return ready;
}
