// hooks/useNotes.ts
import { ensureAnonLogin } from "@/lib/firebase";
import { addNote, removeNote, subscribeNotes } from "@/services/notes";
import { useCallback, useEffect, useState } from "react";

export type Note = { id: string; text: string; ts: number };

export function useNotes(recipeId: string) {
  const [ready, setReady] = useState(false);
  const [items, setItems] = useState<Note[]>([]);
  const [uid, setUid] = useState<string | null>(null);

  useEffect(() => {
    if (!recipeId) return;
    (async () => {
      const u = await ensureAnonLogin();
      setUid(u);
      const unsub = subscribeNotes(u, recipeId, (arr) => {
        setItems(arr);
        setReady(true);
      });
      return () => unsub();
    })();
  }, [recipeId]);

  const add = useCallback(
    async (text: string) => {
      if (!uid) return;
      if (!text.trim()) return;
      await addNote(uid, recipeId, text.trim());
    },
    [uid, recipeId]
  );

  const remove = useCallback(
    async (noteId: string) => {
      if (!uid) return;
      await removeNote(uid, recipeId, noteId);
    },
    [uid, recipeId]
  );

  return { ready, items, add, remove };
}
