// hooks/useRecommended.ts
import { ensureAnonLogin } from '@/lib/firebase';
import { getRecommendedRecipes, Recipe } from '@/services/recipes';
import { useEffect, useRef, useState } from 'react';

export function useRecommended() {
  const [items, setItems] = useState<Recipe[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<unknown>(null);
  const done = useRef(false);

  useEffect(() => {
    let alive = true;

    // 8초 타임아웃 가드 (무한 로딩 방지)
    const t = setTimeout(() => {
      if (!done.current && alive) {
        setError(new Error('요청이 지연되고 있어요(네트워크/규칙 확인 필요)'));
        setLoading(false);
      }
    }, 8000);

    (async () => {
      try {
        await ensureAnonLogin();
        const rows = await getRecommendedRecipes(20);
        if (!alive) return;
        setItems(rows);
      } catch (e) {
        if (!alive) return;
        console.error('[useRecommended] failed:', e);
        setError(e);
      } finally {
        if (!alive) return;
        done.current = true;
        clearTimeout(t);
        setLoading(false);
      }
    })();

    return () => { alive = false; clearTimeout(t); };
  }, []);

  return { items, loading, error };
}
