// hooks/usePantry.ts
import { ensureAnonLogin } from '@/lib/firebase';
import { PantryItem, subscribePantry } from '@/services/pantry';
import type { Unsubscribe } from 'firebase/firestore';
import { useEffect, useState } from 'react';

export function usePantry() {
  const [items, setItems] = useState<PantryItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<unknown>(null);

  useEffect(() => {
    let unsub: Unsubscribe | undefined;
    let mounted = true;

    (async () => {
      try {
        // 🔐 로그인 완료될 때까지 대기
        await ensureAnonLogin();

        unsub = await subscribePantry((list) => {
          if (!mounted) return;
          setItems(list);
          setLoading(false);
        });
      } catch (e) {
        if (!mounted) return;
        setError(e);
        setLoading(false);
      }
    })();

    return () => {
      mounted = false;
      unsub?.();
    };
  }, []);

  return { items, loading, error };
}
