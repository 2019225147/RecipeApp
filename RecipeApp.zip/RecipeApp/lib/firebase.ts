// lib/firebase.ts
import { getApp, getApps, initializeApp } from "firebase/app";
import {
  getAuth,
  onAuthStateChanged,
  signInAnonymously,
  User,
} from "firebase/auth";
import { getFirestore } from "firebase/firestore";
import { getStorage } from "firebase/storage";
import { useEffect, useState } from "react";

const firebaseConfig = {
  apiKey: "AIzaSyDyQKGH5l8jMJzKPIQ5F0U-Z7HIH8REnz4",
  authDomain: "recipe-filter-app.firebaseapp.com",
  projectId: "recipe-filter-app",
  storageBucket: "recipe-filter-app.firebasestorage.app",
  messagingSenderId: "82618020365",
  appId: "1:82618020365:web:d42c3e6350978bc47d5b44",
  measurementId: "G-6560FPHPKY",
};

// ✅ app을 제일 먼저 만들기
export const app = getApps().length ? getApp() : initializeApp(firebaseConfig);

// ✅ 그 다음에 auth/db/storage
export const auth = getAuth(app);
export const db = getFirestore(app);
export const storage = getStorage(app);

// ✅ 익명 로그인 보장 함수 (useFavorites 등에서 사용)
export async function ensureAnonLogin() {
  // 이미 로그인돼 있으면 그대로 반환
  if (auth.currentUser) {
    return auth.currentUser;
  }

  // 아니면 익명 로그인 시도
  const cred = await signInAnonymously(auth);
  return cred.user;
}

// ---- 익명 로그인 + 유저 상태 훅 ----
export function useAuthUser() {
  const [user, setUser] = useState<User | null>(auth.currentUser);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const unsub = onAuthStateChanged(auth, async (u) => {
      if (!u) {
        const cred = await signInAnonymously(auth);
        setUser(cred.user);
      } else {
        setUser(u);
      }
      setLoading(false);
    });
    return unsub;
  }, []);

  return { user, loading };
}
