// constants/types.ts
export type Difficulty = "easy" | "medium" | "hard";

export type Recipe = {
  id: string;
  title: string;
  ingredients: string[];
  time: number;
  difficulty: Difficulty;
  image?: string;
  /** ⬇️ 추가 */
  steps?: string[]; 
  owner?: string;
};
