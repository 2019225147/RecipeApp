// services/favorites.ts
import { auth, db, ensureAnonLogin } from '@/lib/firebase';
import { collection, deleteDoc, doc, getDoc, onSnapshot, setDoc } from 'firebase/firestore';

function favCol(uid: string) {
  return collection(db, 'users', uid, 'favorites');
}

/** 즐겨찾기 토글 (존재하면 삭제, 없으면 생성) */
export async function toggleFavorite(recipeId: string) {
  if (!recipeId) throw new Error('recipeId가 필요합니다.');
  await ensureAnonLogin();
  const uid = auth.currentUser!.uid;
  const ref = doc(favCol(uid), recipeId);
  const snap = await getDoc(ref);
  if (snap.exists()) await deleteDoc(ref);
  else await setDoc(ref, { createdAt: new Date().toISOString() });
}

/** 현재 레시피가 즐겨찾기인지 단건 확인 (선택) */
export async function isFavorite(recipeId: string) {
  await ensureAnonLogin();
  const uid = auth.currentUser!.uid;
  const ref = doc(favCol(uid), recipeId);
  return (await getDoc(ref)).exists();
}

/** 실시간 구독: 즐겨찾기 ID 배열을 콜백으로 전달 */
export async function subscribeFavorites(
  onChange: (ids: string[]) => void,
  onError?: (e: unknown) => void
) {
  await ensureAnonLogin();
  const uid = auth.currentUser!.uid;
  return onSnapshot(
    favCol(uid),
    (snap) => onChange(snap.docs.map((d) => d.id)),
    (err) => {
      console.error('[favorites] snapshot error:', err);
      onError?.(err);
    }
  );
}
