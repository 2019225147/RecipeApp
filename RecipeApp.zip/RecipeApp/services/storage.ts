// services/storage.ts
import { getDownloadURL, ref, uploadBytes } from "firebase/storage";
import { storage } from "../lib/firebase";

// 간단 타임아웃 유틸 (멈춤 방지용)
function withTimeout<T>(p: Promise<T>, ms: number, label: string) {
  let t: any;
  const timeout = new Promise<never>((_, rej) => {
    t = setTimeout(() => rej(new Error(`${label} timeout (${ms}ms)`)), ms);
  });
  return Promise.race([p, timeout]).finally(() => clearTimeout(t));
}

/**
 * 레시피 이미지 업로드
 * @param uid 로그인한 사용자 uid
 * @param localUri expo-image-picker로 받은 로컬 uri
 */
export async function uploadRecipeImageAsync(
  uid: string,
  localUri: string
): Promise<{ downloadUrl: string; path: string }> {
  console.log("[upload] start", { uid, localUri });

  if (!uid) throw new Error("uid is required");
  if (!localUri) throw new Error("localUri is required");

  // localUri -> Blob
  const res = await withTimeout(fetch(localUri), 15000, "fetch(localUri)");
  const blob = await withTimeout(res.blob(), 15000, "res.blob()");
  console.log("[upload] blob ready", { size: (blob as any).size });

  const filename = `${Date.now()}.jpg`;
  const path = `users/${uid}/recipes/${filename}`;
  const storageRef = ref(storage, path);

  // Storage 업로드 (40초 타임아웃)
  await withTimeout(uploadBytes(storageRef, blob), 40000, "uploadBytes");
  console.log("[upload] uploadBytes done");

  const downloadUrl = await withTimeout(
    getDownloadURL(storageRef),
    15000,
    "getDownloadURL"
  );
  console.log("[upload] done", { downloadUrl, path });

  return { downloadUrl, path };
}
