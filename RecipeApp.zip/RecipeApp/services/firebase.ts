// services/firebase.ts
import { initializeApp } from 'firebase/app';
import { getAuth, signInAnonymously } from 'firebase/auth';
import {
    initializeFirestore,
    persistentLocalCache,
    persistentMultipleTabManager,
} from 'firebase/firestore';
import { getStorage } from 'firebase/storage';

// 🔹 Firebase 설정 (expo 환경변수 기반)
// 👉 app.json / app.config.js / .env 등에서 환경변수 설정 필요
const firebaseConfig = {
  apiKey: process.env.EXPO_PUBLIC_FIREBASE_API_KEY,
  authDomain: process.env.EXPO_PUBLIC_FIREBASE_AUTH_DOMAIN,
  projectId: process.env.EXPO_PUBLIC_FIREBASE_PROJECT_ID,
  storageBucket: process.env.EXPO_PUBLIC_FIREBASE_STORAGE_BUCKET,
  messagingSenderId: process.env.EXPO_PUBLIC_FIREBASE_MESSAGING_SENDER_ID,
  appId: process.env.EXPO_PUBLIC_FIREBASE_APP_ID,
};

// 🔹 Firebase 앱 초기화
export const app = initializeApp(firebaseConfig);

// 🔹 Firestore 오프라인 캐시 최신 설정
// 기존 enableIndexedDbPersistence() → ⚠️ deprecated
export const db = initializeFirestore(app, {
  localCache: persistentLocalCache({
    tabManager: persistentMultipleTabManager(),
  }),
});

// 🔹 Auth (익명 로그인)
export const auth = getAuth(app);

// 🔹 Storage (이미지 업로드용)
export const storage = getStorage(app);

// 🔹 앱 시작 시 자동 익명 로그인 (비로그인 방지)
export async function ensureAuth() {
  if (!auth.currentUser) {
    await signInAnonymously(auth);
  }
}
