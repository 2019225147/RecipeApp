// services/recipes.ts
import { auth, db } from '@/lib/firebase';
import {
  addDoc,
  collection,
  deleteDoc,
  doc,
  getDoc,
  getDocs,
  orderBy,
  query,
  Timestamp,
  updateDoc,
} from 'firebase/firestore';

/** ✅ 공통 타입 정의 */
export type Recipe = {
  id?: string;
  title?: string;
  description?: string;
  imageUrl?: string | null;
  ingredients?: string[];
  steps?: string[];
  difficulty?: string;
  time?: number;
  createdAt?: Timestamp | null;
  updatedAt?: Timestamp | null;
};

/** ✅ 익명 로그인 보장 함수 */
async function ensureAnonLogin() {
  const { signInAnonymously } = await import('firebase/auth');
  if (!auth.currentUser) {
    await signInAnonymously(auth);
  }
}

/** ✅ 필드 매핑 함수 (레거시 대응) */
function normalize(d: any, id: string): Recipe {
  return {
    id,
    title: d.title ?? d.name ?? '(제목 없음)',
    description: d.description ?? '',
    imageUrl: d.imageUrl ?? d.image ?? null,
    ingredients: d.ingredients ?? [],
    steps: d.steps ?? [],
    difficulty: d.difficulty ?? '',
    time: d.time ?? null,
    createdAt: d.createdAt ?? null,
    updatedAt: d.updatedAt ?? null,
  };
}

/** ✅ 전체 레시피 목록 불러오기 (레거시 포함) */
export async function listUserRecipes(): Promise<Recipe[]> {
  await ensureAnonLogin();
  const uid = auth.currentUser!.uid;
  const colRef = collection(db, 'users', uid, 'recipes');

  try {
    // createdAt 기준으로 정렬된 최신 문서들
    const snapNew = await getDocs(query(colRef, orderBy('createdAt', 'desc')));
    const rowsNew = snapNew.docs.map((d) => normalize(d.data(), d.id));

    // 레거시 문서 포함 전체 조회
    const snapAll = await getDocs(colRef);
    const rowsAll = snapAll.docs.map((d) => normalize(d.data(), d.id));

    // id 기준으로 병합
    const mergedMap = new Map<string, Recipe>();
    for (const r of [...rowsAll, ...rowsNew]) mergedMap.set(r.id!, r);

    // createdAt 내림차순 정렬 (없으면 뒤로)
    const merged = Array.from(mergedMap.values()).sort((a, b) => {
      const ta = a.createdAt?.toMillis?.() ?? 0;
      const tb = b.createdAt?.toMillis?.() ?? 0;
      return tb - ta;
    });

    console.log('[listUserRecipes] total=', merged.length);
    return merged;
  } catch (e) {
    console.error('[listUserRecipes] failed:', e);
    throw e;
  }
}

/** ✅ 단일 레시피 조회 */
export async function getUserRecipe(id: string) {
  await ensureAnonLogin();
  const uid = auth.currentUser!.uid;
  const ref = doc(db, 'users', uid, 'recipes', id);
  const snap = await getDoc(ref);
  if (!snap.exists()) throw new Error('레시피를 찾을 수 없습니다.');
  return normalize(snap.data(), snap.id);
}

/** ✅ 레시피 생성 */
export async function createUserRecipe(
  data: Omit<Recipe, 'id' | 'createdAt' | 'updatedAt'>
) {
  await ensureAnonLogin();
  const uid = auth.currentUser!.uid;
  const now = Timestamp.now();
  const colRef = collection(db, 'users', uid, 'recipes');
  const docRef = await addDoc(colRef, {
    ...data,
    createdAt: now,
    updatedAt: now,
  });
  return docRef.id;
}

/** ✅ 레시피 수정 */
export async function updateUserRecipe(id: string, data: Partial<Recipe>) {
  await ensureAnonLogin();
  const uid = auth.currentUser!.uid;
  const ref = doc(db, 'users', uid, 'recipes', id);
  await updateDoc(ref, { ...data, updatedAt: Timestamp.now() });
}

/** ✅ 레시피 삭제 */
export async function deleteUserRecipe(id: string) {
  await ensureAnonLogin();
  const uid = auth.currentUser!.uid;
  const ref = doc(db, 'users', uid, 'recipes', id);
  await deleteDoc(ref);
}

/** ✅ 추천 레시피용 (예: 난이도, 시간순 등 간단 필터) */
export async function getRecommendedRecipes(limitCount = 5): Promise<Recipe[]> {
  const all = await listUserRecipes();
  // 예시: 난이도나 시간 기준으로 정렬
  const filtered = all.filter((r) => r.difficulty || r.time);
  return filtered.slice(0, limitCount);
}
