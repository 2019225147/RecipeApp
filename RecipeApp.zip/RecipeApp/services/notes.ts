// services/notes.ts
import { db } from "@/lib/firebase";
import { collection, deleteDoc, doc, onSnapshot, setDoc } from "firebase/firestore";

type NoteItem = { id: string; text: string; ts: number };

const notesCol = (uid: string, recipeId: string) =>
  collection(doc(db, "users", uid), "notes", recipeId, "items");

/** 실시간 구독 */
export function subscribeNotes(
  uid: string,
  recipeId: string,
  cb: (items: NoteItem[]) => void
) {
  return onSnapshot(notesCol(uid, recipeId), (snap) => {
    const items = snap.docs
      .map((d) => ({ id: d.id, ...(d.data() as Omit<NoteItem, "id">) }))
      .sort((a, b) => a.ts - b.ts);
    cb(items);
  });
}

export async function addNote(uid: string, recipeId: string, text: string) {
  const id = Math.random().toString(36).slice(2, 10);
  await setDoc(doc(notesCol(uid, recipeId), id), { text, ts: Date.now() });
}

export async function removeNote(uid: string, recipeId: string, noteId: string) {
  await deleteDoc(doc(notesCol(uid, recipeId), noteId));
}
