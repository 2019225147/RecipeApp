// services/pantry.ts
import { db, ensureAnonLogin } from '@/lib/firebase';
import {
  collection,
  deleteDoc,
  doc,
  onSnapshot,
  orderBy,
  query,
  setDoc,
  Unsubscribe,
} from 'firebase/firestore';

export type PantryItem = {
  id?: string;
  name: string;
  createdAt?: any;
};

// 🔐 로그인 보장 후 uid 반환
async function getUid(): Promise<string> {
  const user = await ensureAnonLogin();
  return user.uid;
}

async function pantryRef() {
  const uid = await getUid();
  return collection(db, 'users', uid, 'pantry');
}

/** 실시간 구독 (반드시 await 해서 unsubscribe 받기) */
export async function subscribePantry(
  onChange: (items: PantryItem[]) => void
): Promise<Unsubscribe> {
  const col = await pantryRef();
  const q = query(col, orderBy('__name__'));
  return onSnapshot(q, (snap) => {
    onChange(snap.docs.map((d) => ({ id: d.id, ...(d.data() as PantryItem) })));
  });
}

export async function addPantryItem(name: string) {
  const id = name.trim().toLowerCase();
  if (!id) return;
  const col = await pantryRef();
  await setDoc(doc(col, id), { name });
}

export async function removePantryItem(id: string) {
  const col = await pantryRef();
  await deleteDoc(doc(col, id));
}
