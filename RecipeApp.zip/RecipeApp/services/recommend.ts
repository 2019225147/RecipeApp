// services/recommend.ts
export type PantryItem = {
  id: string;
  name: string;
};

export type RecipeLike = {
  id: string;
  title: string;
  image?: string;
  time: number;
  difficulty: "easy" | "medium" | "hard";
  ingredients?: { name: string }[];
  tags?: string[];
};

export type ScoredRecipe = RecipeLike & {
  matchCount: number;
  totalNeed: number;
  matchRate: number; // 0~1
  missing: string[];
};

// 간단 정규화(한글/영문 혼합 대비)
export function normalizeName(s: string) {
  return (s || "")
    .toLowerCase()
    .replace(/\s+/g, "")
    .replace(/[^\p{L}\p{N}]/gu, ""); // 문자/숫자만
}

// pantry vs recipe 유사도 계산
export function scoreRecipesByPantry(
  pantry: PantryItem[],
  recipes: RecipeLike[]
): ScoredRecipe[] {
  const pantrySet = new Set(pantry.map((p) => normalizeName(p.name)));

  const scored = recipes.map((r) => {
    const need = (r.ingredients ?? []).map((i) => i.name).filter(Boolean);
    const normNeed = need.map(normalizeName);

    let matchCount = 0;
    const missing: string[] = [];

    normNeed.forEach((ingNorm, idx) => {
      if (pantrySet.has(ingNorm)) matchCount++;
      else missing.push(need[idx]); // 원래 이름으로 누락 표시
    });

    const totalNeed = normNeed.length || 1;
    const matchRate = matchCount / totalNeed;

    return {
      ...r,
      matchCount,
      totalNeed,
      matchRate,
      missing,
    };
  });

  return scored.sort((a, b) => b.matchRate - a.matchRate);
}
