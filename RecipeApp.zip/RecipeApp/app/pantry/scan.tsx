// app/pantry/scan.tsx
import AppHeader from "@/components/AppHeader";
import { db, useAuthUser } from "@/lib/firebase";
import TextRecognition from "@react-native-ml-kit/text-recognition";
import * as ImagePicker from "expo-image-picker";
import { collection, doc, serverTimestamp, setDoc } from "firebase/firestore";
import React, { useState } from "react";
import {
    ActivityIndicator,
    Alert,
    Image,
    Platform,
    Pressable,
    ScrollView,
    StyleSheet,
    Text,
    View,
} from "react-native";

// 간단 slug 함수 (문서 id용)
function slugify(s: string) {
  return s
    .toLowerCase()
    .replace(/\s+/g, "-")
    .replace(/[^a-z0-9ㄱ-ㅎ가-힣\-]/g, "")
    .slice(0, 40);
}

export default function PantryScanScreen() {
  const { user } = useAuthUser();

  const [imageUri, setImageUri] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [candidates, setCandidates] = useState<string[]>([]);
  const [selected, setSelected] = useState<string[]>([]);

  // 📸 이미지 선택 (갤러리)
  async function pickImageFromLibrary() {
    const perm = await ImagePicker.requestMediaLibraryPermissionsAsync();
    if (!perm.granted) {
      Alert.alert("권한 필요", "갤러리 접근 권한을 허용해 주세요.");
      return;
    }

    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.Images,
      quality: 0.8,
    });

    if (result.canceled) return;

    const uri = result.assets?.[0]?.uri;
    if (!uri) return;

    setImageUri(uri);
    setCandidates([]);
    setSelected([]);
    await runTextRecognition(uri);
  }

  // 📷 이미지 선택 (카메라)
  async function pickImageFromCamera() {
    const perm = await ImagePicker.requestCameraPermissionsAsync();
    if (!perm.granted) {
      Alert.alert("권한 필요", "카메라 접근 권한을 허용해 주세요.");
      return;
    }

    const result = await ImagePicker.launchCameraAsync({
      quality: 0.8,
    });

    if (result.canceled) return;

    const uri = result.assets?.[0]?.uri;
    if (!uri) return;

    setImageUri(uri);
    setCandidates([]);
    setSelected([]);
    await runTextRecognition(uri);
  }

  // 🤖 온디바이스 AI(OCR)로 텍스트 인식
  async function runTextRecognition(uri: string) {
    // 웹에서는 ML Kit가 동작하지 않으므로 우회
    if (Platform.OS === "web") {
      Alert.alert(
        "알림",
        "웹 미리보기에서는 AI 인식을 실행하지 않습니다.\n실제 기기(안드로이드/아이폰)에서 실행하면 텍스트 인식이 동작합니다."
      );
      return;
    }

    try {
      setLoading(true);

      const result = await TextRecognition.recognize(uri);
      const allText = result.text ?? "";

      if (!allText.trim()) {
        Alert.alert("인식 결과 없음", "이미지에서 텍스트를 찾지 못했습니다.");
        return;
      }

      // 텍스트를 단어 단위로 잘라서 "재료 후보" 리스트 만들기
      const rawWords = allText
        .split(/[\s,·\n\/]+/)
        .map((w) => w.trim())
        .filter(Boolean);

      const uniq = Array.from(
        new Set(
          rawWords.filter((w) => {
            // 너무 짧은 것(1글자)은 버리고, 기호만 있는 건 제외
            if (w.length < 2) return false;
            if (!/[a-zA-Z0-9ㄱ-ㅎ가-힣]/.test(w)) return false;
            // 숫자만 있는 것도 제외
            if (/^\d+$/.test(w)) return false;
            return true;
          })
        )
      );

      if (uniq.length === 0) {
        Alert.alert(
          "재료 후보 없음",
          "텍스트는 인식했지만, 재료로 쓸만한 단어가 없습니다."
        );
        return;
      }

      setCandidates(uniq);
      // 기본으로 전부 선택 상태
      setSelected(uniq);
    } catch (e: any) {
      console.error(e);
      Alert.alert(
        "인식 실패",
        e?.message ?? "텍스트 인식 중 오류가 발생했습니다."
      );
    } finally {
      setLoading(false);
    }
  }

  // 후보 토글
  function toggleSelect(name: string) {
    setSelected((prev) =>
      prev.includes(name)
        ? prev.filter((n) => n !== name)
        : [...prev, name]
    );
  }

  // 🧊 Firestore pantry에 선택된 재료 추가
  async function saveToPantry() {
    if (!user) {
      return Alert.alert(
        "로그인 필요",
        "사용자 정보가 없습니다. 앱을 다시 실행해 주세요."
      );
    }
    if (selected.length === 0) {
      return Alert.alert(
        "선택된 재료 없음",
        "추가할 재료를 하나 이상 선택해 주세요."
      );
    }

    try {
      setLoading(true);
      const baseCol = collection(db, "users", user.uid, "pantry");

      for (const name of selected) {
        const trimmed = name.trim();
        if (!trimmed) continue;
        const id = slugify(trimmed);

        await setDoc(
          doc(baseCol, id),
          {
            name: trimmed,
            addedAt: serverTimestamp(),
          },
          { merge: true }
        );
      }

      Alert.alert(
        "추가 완료",
        `${selected.length}개의 재료를 보유 재료에 추가했습니다.`
      );
    } catch (e: any) {
      console.error(e);
      Alert.alert(
        "저장 실패",
        e?.message ?? "재료를 저장하는 중 오류가 발생했습니다."
      );
    } finally {
      setLoading(false);
    }
  }

  return (
    <View style={{ flex: 1, backgroundColor: "#fff" }}>
      <AppHeader title="AI로 재료 스캔" showBack />

      <ScrollView
        contentContainerStyle={{
          paddingHorizontal: 16,
          paddingBottom: 24,
        }}
      >
        {/* 안내 텍스트 */}
        <View style={{ marginTop: 12, marginBottom: 12 }}>
          <Text style={styles.desc}>
            냉장고 안, 재료 메모, 상품 포장지 등을 찍으면{"\n"}
            온디바이스 AI가 글자를 인식해서 재료 후보를 찾아줍니다.
          </Text>
        </View>

        {/* 버튼 두 개: 카메라 / 갤러리 */}
        <View style={styles.row}>
          <Pressable
            style={[styles.btn, { backgroundColor: "#0ea5e9" }]}
            onPress={pickImageFromCamera}
          >
            <Text style={styles.btnText}>📷 카메라로 촬영</Text>
          </Pressable>
          <Pressable
            style={[styles.btn, { backgroundColor: "#6366f1" }]}
            onPress={pickImageFromLibrary}
          >
            <Text style={styles.btnText}>🖼 갤러리에서 선택</Text>
          </Pressable>
        </View>

        {/* 이미지 미리보기 */}
        {imageUri && (
          <View style={{ marginTop: 16 }}>
            <Text style={styles.sectionTitle}>선택한 이미지</Text>
            <Image
              source={{ uri: imageUri }}
              style={{
                width: "100%",
                height: 220,
                borderRadius: 16,
                marginTop: 8,
              }}
              resizeMode="cover"
            />
          </View>
        )}

        {/* 인식 중 로딩 */}
        {loading && (
          <View style={styles.center}>
            <ActivityIndicator />
            <Text style={{ marginTop: 8 }}>AI가 이미지를 분석 중입니다…</Text>
          </View>
        )}

        {/* 재료 후보 리스트 */}
        {candidates.length > 0 && (
          <View style={{ marginTop: 20 }}>
            <Text style={styles.sectionTitle}>재료 후보 선택</Text>
            <Text
              style={{
                fontSize: 12,
                color: "#6b7280",
                marginTop: 4,
                marginBottom: 8,
              }}
            >
              추가할 재료만 눌러서 선택/해제한 뒤{"\n"}
              아래 "보유 재료에 추가" 버튼을 눌러 주세요.
            </Text>

            <View style={styles.chipWrap}>
              {candidates.map((name) => {
                const isSelected = selected.includes(name);
                return (
                  <Pressable
                    key={name}
                    onPress={() => toggleSelect(name)}
                    style={[
                      styles.chip,
                      isSelected && styles.chipActive,
                    ]}
                  >
                    <Text
                      style={[
                        styles.chipText,
                        isSelected && styles.chipTextActive,
                      ]}
                    >
                      {name}
                    </Text>
                  </Pressable>
                );
              })}
            </View>

            <Pressable
              style={[
                styles.saveBtn,
                selected.length === 0 && { opacity: 0.5 },
              ]}
              disabled={selected.length === 0 || loading}
              onPress={saveToPantry}
            >
              <Text style={styles.saveBtnText}>
                ✅ 보유 재료에 추가
                {selected.length > 0 ? ` (${selected.length})` : ""}
              </Text>
            </Pressable>
          </View>
        )}
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  desc: {
    fontSize: 13,
    color: "#4b5563",
    lineHeight: 20,
  },
  row: {
    flexDirection: "row",
    gap: 10,
  },
  btn: {
    flex: 1,
    paddingVertical: 10,
    borderRadius: 999,
    alignItems: "center",
  },
  btnText: {
    color: "#fff",
    fontWeight: "700",
    fontSize: 13,
  },
  sectionTitle: {
    fontSize: 15,
    fontWeight: "700",
  },
  center: {
    marginTop: 16,
    alignItems: "center",
  },
  chipWrap: {
    flexDirection: "row",
    flexWrap: "wrap",
    gap: 6,
    marginTop: 4,
  },
  chip: {
    paddingHorizontal: 10,
    paddingVertical: 6,
    borderRadius: 999,
    borderWidth: StyleSheet.hairlineWidth,
    borderColor: "#d1d5db",
    backgroundColor: "#f9fafb",
  },
  chipActive: {
    backgroundColor: "#22c55e",
    borderColor: "#16a34a",
  },
  chipText: {
    fontSize: 12,
    color: "#374151",
  },
  chipTextActive: {
    color: "#fff",
    fontWeight: "700",
  },
  saveBtn: {
    marginTop: 16,
    paddingVertical: 12,
    borderRadius: 999,
    backgroundColor: "#16a34a",
    alignItems: "center",
  },
  saveBtnText: {
    color: "#fff",
    fontWeight: "700",
    fontSize: 14,
  },
});
