// app/pantry/index.tsx
import { useRouter } from "expo-router";
import {
  addDoc,
  collection,
  deleteDoc,
  doc,
  getDocs,
  orderBy,
  query,
  serverTimestamp,
} from "firebase/firestore";
import React, { useCallback, useEffect, useState } from "react";
import {
  ActivityIndicator,
  Alert,
  FlatList,
  KeyboardAvoidingView,
  Platform,
  Pressable,
  StyleSheet,
  Text,
  TextInput,
  View,
} from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";

import { db } from "@/lib/firebase";

type PantryItem = {
  id: string;
  name: string;
  amount?: string;
  unit?: string;
  addedAt?: any;
};

export default function PantryScreen() {
  const router = useRouter();

  const [items, setItems] = useState<PantryItem[]>([]);
  const [loading, setLoading] = useState(true);

  const [name, setName] = useState("");
  const [amount, setAmount] = useState("");
  const [unit, setUnit] = useState("");

  // 🔥 pantry 전체를 한 번 불러오는 함수
  const loadPantry = useCallback(async () => {
    try {
      setLoading(true);
      const q = query(
        collection(db, "pantry"),
        orderBy("addedAt", "desc")
      );
      const snap = await getDocs(q);
      const list: PantryItem[] = snap.docs.map((d) => ({
        id: d.id,
        ...(d.data() as any),
      }));
      setItems(list);
    } catch (e) {
      console.error("❌ pantry load error:", e);
      Alert.alert("오류", "재료 목록을 불러오는 중 문제가 발생했습니다.");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    loadPantry();
  }, [loadPantry]);

  async function handleAdd() {
    const trimmed = name.trim();
    if (!trimmed) {
      Alert.alert("알림", "재료 이름을 입력해 주세요.");
      return;
    }

    try {
      console.log("🔍 pantry 저장 시도:", {
        name: trimmed,
        amount,
        unit,
      });

      const ref = await addDoc(collection(db, "pantry"), {
        name: trimmed,
        amount: amount.trim() || "",
        unit: unit.trim() || "",
        addedAt: serverTimestamp(),
      });

      console.log("✅ pantry 저장 완료:", ref.id);

      setName("");
      setAmount("");
      setUnit("");

      // 🔁 다시 불러오기 (또는 여기서 items에 직접 push해도 됨)
      loadPantry();
    } catch (e) {
      console.error("❌ pantry 저장 실패:", e);
      Alert.alert("오류", "재료를 추가하는 중 문제가 발생했습니다.");
    }
  }

  function confirmDelete(itemId: string) {
    Alert.alert("삭제", "이 재료를 삭제할까요?", [
      { text: "취소", style: "cancel" },
      {
        text: "삭제",
        style: "destructive",
        onPress: () => handleDelete(itemId),
      },
    ]);
  }

  async function handleDelete(itemId: string) {
    try {
      await deleteDoc(doc(db, "pantry", itemId));
      // 삭제 후에도 다시 로딩
      loadPantry();
    } catch (e) {
      console.error("❌ pantry 삭제 실패:", e);
      Alert.alert("오류", "삭제 중 문제가 발생했습니다.");
    }
  }

  if (loading) {
    return (
      <SafeAreaView style={styles.centerContainer}>
        <ActivityIndicator />
        <Text style={{ marginTop: 8 }}>재료 불러오는 중…</Text>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.safeArea}>
      <KeyboardAvoidingView
        style={{ flex: 1 }}
        behavior={Platform.OS === "ios" ? "padding" : undefined}
      >
        {/* 상단 헤더 */}
        <View style={styles.header}>
          <Pressable onPress={() => router.back()}>
            <Text style={styles.backText}>〈 뒤로</Text>
          </Pressable>
          <Text style={styles.headerTitle}>내 냉장고 재료</Text>
          <View style={{ width: 40 }} />
        </View>

        {/* 입력 폼 */}
        <View style={styles.form}>
          <Text style={styles.sectionTitle}>재료 추가</Text>

          <View style={styles.inputRow}>
            <TextInput
              value={name}
              onChangeText={setName}
              placeholder="예: 돼지고기, 양파, 파"
              style={[styles.input, { flex: 2 }]}
            />
          </View>

          <View style={styles.inputRow}>
            <TextInput
              value={amount}
              onChangeText={setAmount}
              placeholder="수량 (예: 1, 200)"
              keyboardType="numeric"
              style={[styles.input, { flex: 1, marginRight: 8 }]}
            />
            <TextInput
              value={unit}
              onChangeText={setUnit}
              placeholder="단위 (예: g, 개)"
              style={[styles.input, { flex: 1 }]}
            />
          </View>

          <Pressable style={styles.addButton} onPress={handleAdd}>
            <Text style={styles.addButtonText}>재료 추가</Text>
          </Pressable>
        </View>

        {/* 재료 리스트 */}
        <View style={styles.listContainer}>
          <Text style={styles.sectionTitle}>보유 중인 재료</Text>

          {items.length === 0 ? (
            <Text style={styles.emptyText}>
              아직 등록된 재료가 없습니다.
              {"\n"}
              위에서 재료를 추가해 보세요.
            </Text>
          ) : (
            <FlatList
              data={items}
              keyExtractor={(item) => item.id}
              contentContainerStyle={{ paddingVertical: 4 }}
              renderItem={({ item }) => (
                <Pressable
                  onLongPress={() => confirmDelete(item.id)}
                  style={styles.itemRow}
                >
                  <View style={{ flex: 1 }}>
                    <Text style={styles.itemName}>{item.name}</Text>
                    {(item.amount || item.unit) && (
                      <Text style={styles.itemMeta}>
                        {item.amount ? `${item.amount}` : ""}
                        {item.unit ? ` ${item.unit}` : ""}
                      </Text>
                    )}
                  </View>
                  <Text style={styles.itemDeleteHint}>길게 눌러 삭제</Text>
                </Pressable>
              )}
            />
          )}
        </View>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: "#ffffff",
  },
  centerContainer: {
    flex: 1,
    backgroundColor: "#ffffff",
    alignItems: "center",
    justifyContent: "center",
  },
  header: {
    paddingHorizontal: 16,
    paddingVertical: 10,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    borderBottomWidth: StyleSheet.hairlineWidth,
    borderBottomColor: "#e5e7eb",
  },
  backText: {
    fontSize: 14,
    color: "#4b5563",
  },
  headerTitle: {
    fontSize: 18,
    fontWeight: "700",
    color: "#111827",
  },
  form: {
    paddingHorizontal: 16,
    paddingTop: 12,
    paddingBottom: 8,
    borderBottomWidth: StyleSheet.hairlineWidth,
    borderBottomColor: "#e5e7eb",
    backgroundColor: "#f9fafb",
  },
  sectionTitle: {
    fontSize: 14,
    fontWeight: "700",
    color: "#111827",
    marginBottom: 8,
  },
  inputRow: {
    flexDirection: "row",
    marginBottom: 8,
  },
  input: {
    borderWidth: StyleSheet.hairlineWidth,
    borderColor: "#d1d5db",
    borderRadius: 10,
    paddingHorizontal: 10,
    paddingVertical: 8,
    fontSize: 13,
    backgroundColor: "#ffffff",
  },
  addButton: {
    marginTop: 4,
    alignSelf: "flex-end",
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 999,
    backgroundColor: "#3b82f6",
  },
  addButtonText: {
    fontSize: 13,
    fontWeight: "700",
    color: "#ffffff",
  },
  listContainer: {
    flex: 1,
    paddingHorizontal: 16,
    paddingTop: 10,
  },
  emptyText: {
    marginTop: 12,
    fontSize: 13,
    color: "#6b7280",
    lineHeight: 18,
  },
  itemRow: {
    flexDirection: "row",
    alignItems: "center",
    paddingVertical: 10,
    paddingHorizontal: 12,
    borderRadius: 12,
    backgroundColor: "#f9fafb",
    marginBottom: 8,
  },
  itemName: {
    fontSize: 14,
    fontWeight: "600",
    color: "#111827",
  },
  itemMeta: {
    marginTop: 2,
    fontSize: 12,
    color: "#6b7280",
  },
  itemDeleteHint: {
    fontSize: 10,
    color: "#9ca3af",
    marginLeft: 8,
  },
});
