// app/recipes/add.tsx
import { useRouter } from "expo-router";
import {
  collection,
  doc,
  serverTimestamp,
  setDoc,
} from "firebase/firestore";
import React, { useMemo, useState } from "react";
import {
  ActivityIndicator,
  Alert,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  View,
} from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import AppHeader from "../../components/AppHeader";
import { db, useAuthUser } from "../../lib/firebase";

function notify(title: string, msg?: string) {
  const text = msg ? `${title}\n${msg}` : title;
  if (Platform.OS === "web") window.alert(text);
  else Alert.alert(title, msg);
}

// 문자열 → 슬러그 ID
function slugify(s: string) {
  return s
    .toLowerCase()
    .replace(/\s+/g, "-")
    .replace(/[^a-z0-9\-]/g, "")
    .slice(0, 40);
}

type Difficulty = "easy" | "medium" | "hard";

export default function AddRecipeScreen() {
  const router = useRouter();
  const { user, loading: authLoading } = useAuthUser();

  const [title, setTitle] = useState("");
  const [ingredients, setIngredients] = useState("");
  const [time, setTime] = useState("");
  const [difficulty, setDifficulty] =
    useState<Difficulty>("easy");
  const [imageUrl, setImageUrl] = useState(""); // 이미지 URL
  const [steps, setSteps] = useState("");

  // ✅ 태그 입력 (쉼표/공백으로 구분)
  const [tagsInput, setTagsInput] = useState("");

  const [saving, setSaving] = useState(false);

  const parsedIngredientsStrings = useMemo(
    () =>
      ingredients
        .split(/[\n,]+/)
        .map((s) => s.trim())
        .filter(Boolean),
    [ingredients]
  );

  const parsedIngredientsObjects = useMemo(
    () =>
      parsedIngredientsStrings.map((name) => ({ name })),
    [parsedIngredientsStrings]
  );

  const parsedSteps = useMemo(
    () =>
      steps
        .split(/\n+/)
        .map((s) => s.trim())
        .filter(Boolean),
    [steps]
  );

  // ✅ 태그 문자열 → 배열 변환
  const parsedTags = useMemo(
    () =>
      tagsInput
        .split(/[,#\s]+/)
        .map((t) => t.trim())
        .filter(Boolean),
    [tagsInput]
  );

  async function onSubmit() {
    if (saving) return;

    if (authLoading) {
      notify("로그인 준비 중", "잠시 후 다시 시도해 주세요.");
      return;
    }

    const t = title.trim();
    const tm = Number(time);
    const uid = user?.uid ?? null;

    if (!t) return notify("필수 입력", "제목을 입력해 주세요.");
    if (!parsedIngredientsStrings.length)
      return notify(
        "필수 입력",
        "재료를 한 개 이상 입력해 주세요."
      );
    if (!Number.isFinite(tm) || tm <= 0)
      return notify(
        "입력 오류",
        "조리 시간을 숫자로 입력해 주세요."
      );
    if (!uid) return notify("로그인이 필요합니다");

    const id =
      slugify(t) || Math.random().toString(36).slice(2, 10);
    const now = serverTimestamp();

    setSaving(true);

    try {
      const img = imageUrl.trim();

      const payload = {
        title: t,
        imageUrl: img,
        image: img,
        imagePath: "",
        time: tm,
        difficulty,
        // ✅ 태그 배열 저장
        tags: parsedTags,
        description: "",
        ingredients: parsedIngredientsObjects,
        steps: parsedSteps,
        createdAt: now,
        updatedAt: now,
      };

      // 공용 recipes
      await setDoc(
        doc(collection(db, "recipes"), id),
        payload,
        {
          merge: true,
        }
      );

      // 내 recipes (추후 확장용)
      await setDoc(
        doc(collection(db, "users", uid, "recipes"), id),
        payload,
        {
          merge: true,
        }
      );

      if (Platform.OS === "web") {
        window.alert("저장 완료!\n레시피가 추가되었습니다.");
        router.replace(`/recipes/${id}`);
      } else {
        Alert.alert("저장 완료", "레시피가 추가되었습니다.", [
          {
            text: "확인",
            onPress: () => router.replace(`/recipes/${id}`),
          },
        ]);
      }
    } catch (e: any) {
      console.error(e);
      notify("저장 실패", String(e?.message ?? e));
    } finally {
      setSaving(false);
    }
  }

  return (
    <SafeAreaView style={styles.safe}>
      <AppHeader title="레시피 추가" showBack />

      <ScrollView
        contentContainerStyle={styles.container}
        keyboardShouldPersistTaps="handled"
      >
        {/* 제목 */}
        <Text style={styles.label}>제목</Text>
        <TextInput
          value={title}
          onChangeText={setTitle}
          placeholder="예) 마파두부"
          style={styles.input}
        />

        {/* 재료 */}
        <Text style={styles.label}>
          재료 (쉼표 또는 줄바꿈으로 구분)
        </Text>
        <TextInput
          value={ingredients}
          onChangeText={setIngredients}
          placeholder="두부, 다진마늘, 대파, 고추기름"
          style={[styles.input, styles.multiline]}
          multiline
        />

        {/* 조리 시간 */}
        <Text style={styles.label}>조리 시간(분)</Text>
        <TextInput
          value={time}
          onChangeText={setTime}
          placeholder="예) 15"
          keyboardType="numeric"
          style={styles.input}
        />

        {/* 난이도 */}
        <Text style={styles.label}>난이도</Text>
        <View style={styles.row}>
          {(["easy", "medium", "hard"] as const).map((d) => (
            <Pressable
              key={d}
              onPress={() => setDifficulty(d)}
              style={
                difficulty === d
                  ? styles.chipActive
                  : styles.chip
              }
            >
              <Text
                style={
                  difficulty === d
                    ? styles.chipTextActive
                    : styles.chipText
                }
              >
                {d}
              </Text>
            </Pressable>
          ))}
        </View>

        {/* 이미지 URL */}
        <Text style={styles.label}>
          이미지 URL (선택)
        </Text>
        <TextInput
          value={imageUrl}
          onChangeText={setImageUrl}
          placeholder="https://…/photo.jpg"
          style={styles.input}
        />

        {/* ✅ 태그 입력 */}
        <Text style={styles.label}>
          태그 (쉼표 또는 공백으로 구분, 선택)
        </Text>
        <TextInput
          value={tagsInput}
          onChangeText={setTagsInput}
          placeholder="예) 한식, 매운맛, 야식"
          style={styles.input}
        />
        {parsedTags.length > 0 && (
          <View
            style={{
              flexDirection: "row",
              flexWrap: "wrap",
              marginTop: 6,
            }}
          >
            {parsedTags.map((tag) => (
              <View
                key={tag}
                style={{
                  paddingHorizontal: 8,
                  paddingVertical: 4,
                  borderRadius: 999,
                  backgroundColor: "#eef2ff",
                  marginRight: 6,
                  marginBottom: 4,
                }}
              >
                <Text
                  style={{
                    fontSize: 11,
                    color: "#4f46e5",
                    fontWeight: "700",
                  }}
                >
                  #{tag}
                </Text>
              </View>
            ))}
          </View>
        )}

        {/* 조리 단계 */}
        <Text style={styles.label}>
          조리 단계 (줄바꿈으로 구분, 선택)
        </Text>
        <TextInput
          value={steps}
          onChangeText={setSteps}
          placeholder={"1) 팬 달구기\n2) 재료 볶기\n3) 간 맞추기"}
          style={[styles.input, styles.multiline]}
          multiline
        />

        {/* 저장 버튼 */}
        <Pressable
          onPress={onSubmit}
          style={[styles.btn, saving && { opacity: 0.7 }]}
        >
          {saving ? (
            <View
              style={{
                flexDirection: "row",
                alignItems: "center",
              }}
            >
              <ActivityIndicator color="#fff" />
              <Text
                style={[styles.btnText, { marginLeft: 8 }]}
              >
                저장 중…
              </Text>
            </View>
          ) : (
            <Text style={styles.btnText}>저장</Text>
          )}
        </Pressable>

        <View style={{ height: 16 }} />
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: {
    flex: 1,
    backgroundColor: "#ffffff", // 🔥 전체 배경 흰색
  },
  container: {
    padding: 16,
    paddingBottom: 24,
  },
  label: {
    fontSize: 14,
    fontWeight: "700",
    marginTop: 10,
    marginBottom: 6,
  },
  row: {
    flexDirection: "row",
    alignItems: "center",
    marginBottom: 8,
  },
  input: {
    borderWidth: StyleSheet.hairlineWidth,
    borderColor: "#d1d5db",
    borderRadius: 10,
    paddingHorizontal: 12,
    paddingVertical: 10,
    backgroundColor: "#fff",
  },
  multiline: { minHeight: 80, textAlignVertical: "top" },
  chip: {
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: 999,
    borderWidth: StyleSheet.hairlineWidth,
    borderColor: "#cbd5e1",
    backgroundColor: "#f3f4f6",
    marginRight: 8,
  },
  chipActive: {
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: 999,
    borderWidth: StyleSheet.hairlineWidth,
    borderColor: "#2563eb",
    backgroundColor: "#2563eb",
    marginRight: 8,
  },
  chipText: {
    fontSize: 12,
    fontWeight: "700",
    color: "#111827",
  },
  chipTextActive: {
    fontSize: 12,
    fontWeight: "700",
    color: "#fff",
  },
  btn: {
    backgroundColor: "#3b82f6",
    paddingHorizontal: 18,
    paddingVertical: 12,
    borderRadius: 12,
    marginTop: 16,
    alignItems: "center",
  },
  btnText: { color: "#fff", fontWeight: "700" },
});
