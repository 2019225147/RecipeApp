// app/recipes/[id]/cook.tsx
import { useLocalSearchParams, useRouter } from "expo-router";
import { doc, getDoc } from "firebase/firestore";
import React, { useEffect, useMemo, useState } from "react";
import {
    ActivityIndicator,
    Pressable,
    StyleSheet,
    Text,
    View,
} from "react-native";
import AppHeader from "../../../components/AppHeader";
import { db } from "../../../lib/firebase";

type Recipe = {
  id: string;
  title: string;
  steps?: string[];
  time?: number;
};

export default function CookModeScreen() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const router = useRouter();

  const [recipe, setRecipe] = useState<Recipe | null>(null);
  const [loading, setLoading] = useState(true);
  const [stepIndex, setStepIndex] = useState(0);

  // 레시피 불러오기 (steps만 사용)
  useEffect(() => {
    if (!id || typeof id !== "string") return;

    const ref = doc(db, "recipes", id);
    getDoc(ref)
      .then((snap) => {
        if (!snap.exists()) {
          setRecipe(null);
        } else {
          const data = snap.data() as any;
          setRecipe({
            id: snap.id,
            title: data.title ?? "레시피",
            steps: data.steps ?? [],
            time: data.time,
          });
        }
      })
      .finally(() => setLoading(false));
  }, [id]);

  const steps = useMemo(
    () => recipe?.steps ?? [],
    [recipe?.steps]
  );

  const total = steps.length;

  const canPrev = stepIndex > 0;
  const canNext = stepIndex < total - 1;

  function goPrev() {
    if (!canPrev) return;
    setStepIndex((i) => i - 1);
  }

  function goNext() {
    if (!canNext) return;
    setStepIndex((i) => i + 1);
  }

  if (loading) {
    return (
      <View style={styles.center}>
        <ActivityIndicator />
        <Text style={{ marginTop: 8 }}>
          요리 모드 준비 중…
        </Text>
      </View>
    );
  }

  if (!recipe) {
    return (
      <View style={styles.center}>
        <Text>레시피를 찾을 수 없습니다.</Text>
      </View>
    );
  }

  if (!total) {
    return (
      <View style={{ flex: 1, backgroundColor: "#fff" }}>
        <AppHeader title="요리 모드" showBack />
        <View style={styles.center}>
          <Text style={{ color: "#6b7280" }}>
            이 레시피에는 조리 단계 정보가 없습니다.
          </Text>
        </View>
      </View>
    );
  }

  const currentStep = steps[stepIndex];

  return (
    <View style={{ flex: 1, backgroundColor: "#020617" }}>
      <AppHeader title="요리 모드" showBack />

      <View style={styles.cookContainer}>
        {/* 상단 정보 */}
        <View style={styles.topInfo}>
          <Text style={styles.recipeTitle}>{recipe.title}</Text>
          <Text style={styles.stepInfo}>
            {stepIndex + 1} / {total} 단계
          </Text>
        </View>

        {/* 중앙 큰 글씨 단계 */}
        <View style={styles.stepBox}>
          <Text style={styles.stepText}>{currentStep}</Text>
        </View>

        {/* 하단 버튼들 */}
        <View style={styles.buttonRow}>
          <Pressable
            onPress={goPrev}
            style={[
              styles.navBtn,
              !canPrev && styles.navBtnDisabled,
            ]}
            disabled={!canPrev}
          >
            <Text
              style={[
                styles.navBtnText,
                !canPrev && styles.navBtnTextDisabled,
              ]}
            >
              이전 단계
            </Text>
          </Pressable>

          {canNext ? (
            <Pressable
              onPress={goNext}
              style={styles.navBtn}
            >
              <Text style={styles.navBtnText}>
                다음 단계
              </Text>
            </Pressable>
          ) : (
            <Pressable
              onPress={() =>
                router.replace(`/recipes/${recipe.id}`)
              }
              style={[styles.navBtn, styles.finishBtn]}
            >
              <Text style={styles.navBtnText}>
                완료하고 나가기
              </Text>
            </Pressable>
          )}
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  center: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: "#fff",
  },
  cookContainer: {
    flex: 1,
    paddingHorizontal: 16,
    paddingBottom: 24,
    paddingTop: 12,
  },
  topInfo: {
    alignItems: "center",
    marginBottom: 24,
  },
  recipeTitle: {
    fontSize: 18,
    fontWeight: "800",
    color: "#e5e7eb",
  },
  stepInfo: {
    marginTop: 4,
    fontSize: 13,
    color: "#9ca3af",
  },
  stepBox: {
    flex: 1,
    borderRadius: 24,
    backgroundColor: "#020617",
    borderWidth: 1,
    borderColor: "#1f2937",
    padding: 20,
    justifyContent: "center",
  },
  stepText: {
    fontSize: 22,
    color: "#f9fafb",
    lineHeight: 32,
    textAlign: "center",
  },
  buttonRow: {
    marginTop: 24,
    flexDirection: "row",
    justifyContent: "space-between",
    gap: 12,
  },
  navBtn: {
    flex: 1,
    paddingVertical: 12,
    borderRadius: 999,
    backgroundColor: "#0ea5e9",
    alignItems: "center",
  },
  navBtnDisabled: {
    backgroundColor: "#1f2937",
  },
  finishBtn: {
    backgroundColor: "#22c55e",
  },
  navBtnText: {
    color: "#f9fafb",
    fontWeight: "700",
    fontSize: 14,
  },
  navBtnTextDisabled: {
    color: "#6b7280",
  },
});
