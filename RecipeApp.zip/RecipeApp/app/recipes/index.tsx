// app/recipes/index.tsx
import { useRouter } from "expo-router";
import {
  collection,
  query as fsQuery,
  onSnapshot,
  orderBy,
} from "firebase/firestore";
import React, { useEffect, useMemo, useState } from "react";
import {
  ActivityIndicator,
  Dimensions,
  Modal,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from "react-native";
import AppHeader from "../../components/AppHeader";
import RecipeCard, { type RecipeCardBadge } from "../../components/RecipeCard";
import { db } from "../../lib/firebase";

type Recipe = {
  id: string;
  title: string;
  description?: string;
  imageUrl?: string;
  image?: string;
  time?: number;
  difficulty?: "easy" | "medium" | "hard" | string;
  ingredients?: { name: string }[];
  tags?: string[];
  createdAt?: any;
};

const { width } = Dimensions.get("window");
// 카드 자체 정사각형 크기 (화면 절반 - 여백)
const GRID_ITEM_SIZE = width / 2 - 32;

// TS에서 RecipeCard prop 맞추기 귀찮을 때 any로 우회
const RecipeCardAny = RecipeCard as any;

type ViewType = "grid" | "list";
type SortType = "latest" | "timeAsc";

// 상단에만 노출할 "대표 태그" (실제 사용하는 태그명에 맞게 수정 가능)
const MAIN_TAGS = ["한식", "중식", "양식", "일식", "디저트", "면요리", "국/찌개"];

export default function RecipesScreen() {
  const router = useRouter();

  const [recipes, setRecipes] = useState<Recipe[]>([]);
  const [loading, setLoading] = useState(true);

  const [view, setView] = useState<ViewType>("grid");
  const [sort, setSort] = useState<SortType>("latest");
  const [search, setSearch] = useState<string>("");
  const [selectedTags, setSelectedTags] = useState<string[]>([]);
  const [showTagModal, setShowTagModal] = useState(false);

  // 🔥 Firestore에서 레시피 목록 구독
  // 👉 여기서 createdBy 필터(내 레시피만 보기)는 아예 사용하지 않음 = 전체 레시피 조회
  useEffect(() => {
    const q = fsQuery(
      collection(db, "recipes"),
      orderBy("createdAt", "desc")
    );

    const unsub = onSnapshot(
      q,
      (snap) => {
        const items: Recipe[] = snap.docs.map((d) => ({
          id: d.id,
          ...(d.data() as any),
        }));
        setRecipes(items);
        setLoading(false);
      },
      (err) => {
        console.error(err);
        setLoading(false);
      }
    );

    return () => unsub();
  }, []);

  // 전체 태그 목록 (중복 제거)
  const allTags = useMemo(() => {
    const set = new Set<string>();
    recipes.forEach((r) => (r.tags ?? []).forEach((t) => set.add(t)));
    return Array.from(set);
  }, [recipes]);

  // 상단(쿠팡 스타일 바)에만 보여줄 대표 태그
  const mainTags = useMemo(
    () => allTags.filter((tag) => MAIN_TAGS.includes(tag)),
    [allTags]
  );

  // 검색 + 태그 + 정렬 적용된 목록
  const filtered = useMemo(() => {
    let list = [...recipes];

    const q = (search ?? "").trim().toLowerCase();

    // 검색 (제목 / 설명 / 태그)
    if (q) {
      list = list.filter((r) => {
        const text =
          (r.title ?? "") +
          " " +
          (r.description ?? "") +
          " " +
          (r.tags ?? []).join(" ");
        return text.toLowerCase().includes(q);
      });
    }

    // 태그 필터 (모든 선택된 태그를 포함하는 레시피만)
    if (selectedTags.length > 0) {
      list = list.filter((r) => {
        const rt = r.tags ?? [];
        return selectedTags.every((t) => rt.includes(t));
      });
    }

    // 정렬
    if (sort === "timeAsc") {
      list.sort((a, b) => {
        const ta = a.time ?? 9999;
        const tb = b.time ?? 9999;
        return ta - tb;
      });
    }
    // latest 는 Firestore에서 desc라 그대로

    return list;
  }, [recipes, search, selectedTags, sort]);

  function toggleTag(tag: string) {
    setSelectedTags((prev) =>
      prev.includes(tag) ? prev.filter((t) => t !== tag) : [...prev, tag]
    );
  }

  function clearTags() {
    setSelectedTags([]);
  }

  function toggleSort() {
    setSort((prev) => (prev === "latest" ? "timeAsc" : "latest"));
  }

  function makeBadges(r: Recipe): RecipeCardBadge[] {
    const badges: RecipeCardBadge[] = [];
    if (typeof r.time === "number") {
      badges.push({
        text: `${r.time}분`,
        tone: "dark",
      });
    }
    if (r.difficulty) {
      badges.push({
        text: r.difficulty,
        tone: "light",
      });
    }
    if (r.ingredients && r.ingredients.length > 0) {
      badges.push({
        text: `${r.ingredients.length}개 재료`,
        tone: "light",
      });
    }
    return badges;
  }

  return (
    <View style={{ flex: 1, backgroundColor: "#fff" }}>
      <AppHeader title="레시피 목록" showBack />

      {loading ? (
        <View style={styles.center}>
          <ActivityIndicator />
          <Text style={{ marginTop: 8 }}>레시피 불러오는 중…</Text>
        </View>
      ) : (
        <>
          <ScrollView
            contentContainerStyle={{
              paddingHorizontal: 16,
              paddingBottom: 24,
            }}
          >
            {/* 🔍 검색 */}
            <View style={styles.topRow}>
              <TextInput
                value={search ?? ""}
                onChangeText={setSearch}
                placeholder="검색 (제목/설명/태그)"
                style={styles.searchInput}
              />
            </View>

            {/* 뷰 전환 + 정렬 */}
            <View style={styles.topRow2}>
              <View style={styles.viewToggle}>
                <Pressable
                  onPress={() => setView("grid")}
                  style={[
                    styles.viewChip,
                    view === "grid" && styles.viewChipActive,
                  ]}
                >
                  <Text
                    style={[
                      styles.viewChipText,
                      view === "grid" && styles.viewChipTextActive,
                    ]}
                  >
                    그리드
                  </Text>
                </Pressable>
                <Pressable
                  onPress={() => setView("list")}
                  style={[
                    styles.viewChip,
                    view === "list" && styles.viewChipActive,
                  ]}
                >
                  <Text
                    style={[
                      styles.viewChipText,
                      view === "list" && styles.viewChipTextActive,
                    ]}
                  >
                    리스트
                  </Text>
                </Pressable>
              </View>

              <Pressable onPress={toggleSort} style={styles.sortBtn}>
                <Text style={styles.sortBtnText}>
                  정렬:{" "}
                  {sort === "latest" ? "최신순" : "조리시간 오름차순"}
                </Text>
              </Pressable>
            </View>

            {/* 🏷 쿠팡 스타일 태그 필터 */}
            {allTags.length > 0 && (
              <View style={{ marginTop: 10 }}>
                <View
                  style={{
                    flexDirection: "row",
                    justifyContent: "space-between",
                    alignItems: "center",
                    marginBottom: 4,
                  }}
                >
                  <View>
                    <Text
                      style={{
                        fontSize: 13,
                        fontWeight: "700",
                      }}
                    >
                      태그 필터
                    </Text>
                    <Text
                      style={{
                        fontSize: 11,
                        color: "#6b7280",
                        marginTop: 2,
                      }}
                    >
                      대표 태그 + 전체보기 모아보기
                    </Text>
                  </View>

                  {selectedTags.length > 0 && (
                    <Pressable onPress={clearTags}>
                      <Text
                        style={{
                          fontSize: 11,
                          color: "#3b82f6",
                        }}
                      >
                        필터 초기화
                      </Text>
                    </Pressable>
                  )}
                </View>

                {/* 상단 바: 전체 + 대표 태그 + 태그 전체보기 버튼 */}
                <ScrollView horizontal showsHorizontalScrollIndicator={false}>
                  {/* 전체 */}
                  <Pressable
                    onPress={clearTags}
                    style={[
                      styles.tagChip,
                      selectedTags.length === 0 && styles.tagChipActive,
                    ]}
                  >
                    <Text
                      style={[
                        styles.tagChipText,
                        selectedTags.length === 0 &&
                          styles.tagChipTextActive,
                      ]}
                    >
                      전체
                    </Text>
                  </Pressable>

                  {/* 대표 태그들만 노출 */}
                  {mainTags.map((tag) => {
                    const active = selectedTags.includes(tag);
                    return (
                      <Pressable
                        key={tag}
                        onPress={() => toggleTag(tag)}
                        style={[
                          styles.tagChip,
                          active && styles.tagChipActive,
                        ]}
                      >
                        <Text
                          style={[
                            styles.tagChipText,
                            active && styles.tagChipTextActive,
                          ]}
                        >
                          #{tag}
                        </Text>
                      </Pressable>
                    );
                  })}

                  {/* 태그 전체보기 버튼 */}
                  <Pressable
                    onPress={() => setShowTagModal(true)}
                    style={[styles.tagChip, styles.tagMoreChip]}
                  >
                    <Text style={styles.tagMoreChipText}>
                      + 태그 전체보기
                    </Text>
                  </Pressable>
                </ScrollView>

                {/* 현재 선택된 태그 요약 */}
                {selectedTags.length > 0 && (
                  <Text
                    style={{
                      marginTop: 4,
                      fontSize: 11,
                      color: "#4b5563",
                    }}
                    numberOfLines={1}
                  >
                    선택된 태그: {selectedTags.join(", ")}
                  </Text>
                )}
              </View>
            )}

            {/* 📚 레시피 목록 영역 */}
            <View style={{ marginTop: 16 }}>
              {filtered.length === 0 ? (
                <Text style={{ color: "#6b7280", marginTop: 8 }}>
                  조건에 맞는 레시피가 없습니다.
                </Text>
              ) : view === "grid" ? (
                // 🔳 2열 그리드 뷰
                <View style={styles.gridContainer}>
                  {filtered.map((r) => {
                    const cardItem = {
                      ...r,
                      imageUrl: r.imageUrl || r.image || "",
                    };
                    return (
                      <View key={r.id} style={styles.gridItem}>
                        <RecipeCardAny
                          item={cardItem}
                          size={GRID_ITEM_SIZE}
                          topLeftBadges={makeBadges(r)}
                        />
                      </View>
                    );
                  })}
                </View>
              ) : (
                // 📋 리스트 뷰
                <View style={{ gap: 10 }}>
                  {filtered.map((r) => (
                    <Pressable
                      key={r.id}
                      style={styles.listItem}
                      onPress={() => router.push(`/recipes/${r.id}`)}
                    >
                      <View style={{ flex: 1 }}>
                        <Text
                          style={{
                            fontSize: 16,
                            fontWeight: "700",
                          }}
                          numberOfLines={1}
                        >
                          {r.title}
                        </Text>
                        <Text
                          style={{
                            fontSize: 12,
                            color: "#6b7280",
                            marginTop: 2,
                          }}
                          numberOfLines={1}
                        >
                          {r.time ? `${r.time}분 · ` : ""}
                          {r.difficulty ?? "난이도 정보 없음"}
                        </Text>

                        <View
                          style={{
                            flexDirection: "row",
                            flexWrap: "wrap",
                            marginTop: 4,
                          }}
                        >
                          {(r.tags ?? []).slice(0, 3).map((t) => (
                            <View key={t} style={styles.smallTagChip}>
                              <Text
                                style={{
                                  fontSize: 10,
                                  color: "#4f46e5",
                                }}
                              >
                                #{t}
                              </Text>
                            </View>
                          ))}
                        </View>
                      </View>

                      <Text
                        style={{
                          fontSize: 12,
                          color: "#3b82f6",
                          marginLeft: 10,
                        }}
                      >
                        상세보기 →
                      </Text>
                    </Pressable>
                  ))}
                </View>
              )}
            </View>
          </ScrollView>

          {/* 🪟 태그 전체보기 모달 */}
          <Modal
            visible={showTagModal}
            transparent
            animationType="slide"
            onRequestClose={() => setShowTagModal(false)}
          >
            <View style={styles.modalOverlay}>
              <View style={styles.modalContent}>
                <View style={styles.modalHeader}>
                  <Text style={styles.modalTitle}>태그 전체 보기</Text>
                  <TouchableOpacity
                    onPress={() => setShowTagModal(false)}
                  >
                    <Text style={styles.modalCloseText}>닫기</Text>
                  </TouchableOpacity>
                </View>

                <ScrollView>
                  <View style={styles.modalTagGrid}>
                    {/* 전체 선택(초기화) */}
                    <Pressable
                      onPress={clearTags}
                      style={[
                        styles.tagChip,
                        styles.modalTagChip,
                        selectedTags.length === 0 &&
                          styles.tagChipActive,
                      ]}
                    >
                      <Text
                        style={[
                          styles.tagChipText,
                          selectedTags.length === 0 &&
                            styles.tagChipTextActive,
                        ]}
                      >
                        전체
                      </Text>
                    </Pressable>

                    {allTags.map((tag) => {
                      const active = selectedTags.includes(tag);
                      return (
                        <Pressable
                          key={tag}
                          onPress={() => toggleTag(tag)}
                          style={[
                            styles.tagChip,
                            styles.modalTagChip,
                            active && styles.tagChipActive,
                          ]}
                        >
                          <Text
                            style={[
                              styles.tagChipText,
                              active && styles.tagChipTextActive,
                            ]}
                          >
                            #{tag}
                          </Text>
                        </Pressable>
                      );
                    })}
                  </View>
                </ScrollView>

                <View style={styles.modalFooter}>
                  {selectedTags.length > 0 && (
                    <Pressable
                      onPress={clearTags}
                      style={[
                        styles.modalFooterButton,
                        styles.modalFooterButtonSecondary,
                      ]}
                    >
                      <Text
                        style={{
                          fontSize: 13,
                          color: "#4b5563",
                        }}
                      >
                        필터 초기화
                      </Text>
                    </Pressable>
                  )}

                  <Pressable
                    onPress={() => setShowTagModal(false)}
                    style={[
                      styles.modalFooterButton,
                      styles.modalFooterButtonPrimary,
                    ]}
                  >
                    <Text
                      style={{
                        fontSize: 13,
                        color: "#fff",
                        fontWeight: "700",
                      }}
                    >
                      적용하기
                    </Text>
                  </Pressable>
                </View>
              </View>
            </View>
          </Modal>
        </>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  center: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
  },

  topRow: {
    marginTop: 12,
  },
  topRow2: {
    marginTop: 8,
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
  },

  searchInput: {
    borderWidth: StyleSheet.hairlineWidth,
    borderColor: "#d1d5db",
    borderRadius: 999,
    paddingHorizontal: 14,
    paddingVertical: 8,
    backgroundColor: "#f9fafb",
    fontSize: 13,
  },

  viewToggle: {
    flexDirection: "row",
    backgroundColor: "#e5e7eb",
    borderRadius: 999,
    padding: 2,
  },
  viewChip: {
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 999,
  },
  viewChipActive: {
    backgroundColor: "#fff",
  },
  viewChipText: {
    fontSize: 11,
    color: "#4b5563",
    fontWeight: "700",
  },
  viewChipTextActive: {
    color: "#111827",
  },

  sortBtn: {
    paddingHorizontal: 10,
    paddingVertical: 6,
    borderRadius: 999,
    borderWidth: StyleSheet.hairlineWidth,
    borderColor: "#d1d5db",
    backgroundColor: "#fff",
  },
  sortBtnText: {
    fontSize: 11,
    fontWeight: "700",
    color: "#111827",
  },

  tagChip: {
    paddingHorizontal: 10,
    paddingVertical: 6,
    borderRadius: 999,
    borderWidth: StyleSheet.hairlineWidth,
    borderColor: "#e5e7eb",
    backgroundColor: "#f9fafb",
    marginRight: 8,
    marginBottom: 6,
  },
  tagChipActive: {
    backgroundColor: "#4f46e5",
    borderColor: "#4f46e5",
  },
  tagChipText: {
    fontSize: 11,
    color: "#374151",
  },
  tagChipTextActive: {
    color: "#fff",
    fontWeight: "700",
  },
  tagMoreChip: {
    borderStyle: "dashed",
    borderColor: "#c7d2fe",
    backgroundColor: "#eef2ff",
  },
  tagMoreChipText: {
    fontSize: 11,
    color: "#4f46e5",
    fontWeight: "600",
  },

  // 🔳 2열 그리드 레이아웃
  gridContainer: {
    flexDirection: "row",
    flexWrap: "wrap",
    marginHorizontal: -6, // 좌우 패딩 대응
  },
  gridItem: {
    width: "50%", // 무조건 2칸
    paddingHorizontal: 6,
    marginBottom: 12,
  },

  // 리스트 카드
  listItem: {
    flexDirection: "row",
    alignItems: "center",
    padding: 12,
    borderRadius: 12,
    backgroundColor: "#f9fafb",
  },
  smallTagChip: {
    paddingHorizontal: 6,
    paddingVertical: 2,
    borderRadius: 999,
    backgroundColor: "#eef2ff",
    marginRight: 4,
    marginBottom: 3,
  },

  // 🔽 태그 전체보기 모달
  modalOverlay: {
    flex: 1,
    backgroundColor: "rgba(0,0,0,0.25)",
    justifyContent: "flex-end",
  },
  modalContent: {
    maxHeight: "70%",
    backgroundColor: "#fff",
    borderTopLeftRadius: 16,
    borderTopRightRadius: 16,
    paddingTop: 12,
    paddingHorizontal: 16,
    paddingBottom: 16,
  },
  modalHeader: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    marginBottom: 8,
  },
  modalTitle: {
    fontSize: 16,
    fontWeight: "700",
  },
  modalCloseText: {
    fontSize: 13,
    color: "#6b7280",
  },
  modalTagGrid: {
    flexDirection: "row",
    flexWrap: "wrap",
    marginTop: 8,
  },
  modalTagChip: {
    marginRight: 6,
    marginBottom: 6,
  },
  modalFooter: {
    flexDirection: "row",
    justifyContent: "flex-end",
    marginTop: 12,
    gap: 8,
  },
  modalFooterButton: {
    paddingHorizontal: 14,
    paddingVertical: 8,
    borderRadius: 999,
  },
  modalFooterButtonSecondary: {
    borderWidth: StyleSheet.hairlineWidth,
    borderColor: "#d1d5db",
    backgroundColor: "#f9fafb",
  },
  modalFooterButtonPrimary: {
    backgroundColor: "#4f46e5",
  },
});
