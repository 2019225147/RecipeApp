// app/recipes/[id].tsx
import { useLocalSearchParams, useRouter } from "expo-router";
import {
    collection,
    doc,
    query as fsQuery,
    getDoc,
    getDocs,
    limit,
    onSnapshot,
    orderBy,
} from "firebase/firestore";
import React, { useEffect, useMemo, useState } from "react";
import {
    ActivityIndicator,
    Pressable,
    ScrollView,
    StyleSheet,
    Text,
    View,
} from "react-native";
import AppHeader from "../../components/AppHeader";
import RecipeCard from "../../components/RecipeCard";
import { db, useAuthUser } from "../../lib/firebase";

type Ingredient = { name: string } | string;

type Recipe = {
  id: string;
  title: string;
  description?: string;
  imageUrl?: string;
  image?: string;
  time?: number;
  difficulty?: "easy" | "medium" | "hard" | string;
  ingredients?: Ingredient[];
  steps?: string[];
  tags?: string[];
  createdAt?: any;
};

type PantryItem = {
  id: string;
  name: string;
  amount?: string;
  unit?: string;
};

const RecipeCardAny = RecipeCard as any;

export default function RecipeDetailScreen() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const router = useRouter();
  const { user, loading: authLoading } = useAuthUser();

  const [recipe, setRecipe] = useState<Recipe | null>(null);
  const [loading, setLoading] = useState(true);

  const [related, setRelated] = useState<Recipe[]>([]);

  const [pantry, setPantry] = useState<PantryItem[]>([]);

  // 🔥 선택한 레시피 불러오기
  useEffect(() => {
    if (!id || typeof id !== "string") return;

    const ref = doc(db, "recipes", id);
    getDoc(ref)
      .then((snap) => {
        if (!snap.exists()) {
          setRecipe(null);
        } else {
          setRecipe({
            id: snap.id,
            ...(snap.data() as any),
          });
        }
      })
      .finally(() => setLoading(false));
  }, [id]);

  // 🔥 관련 레시피 (단순: 최신 10개 중에서 현재 레시피 제외)
  useEffect(() => {
    if (!recipe) return;

    const q = fsQuery(
      collection(db, "recipes"),
      orderBy("createdAt", "desc"),
      limit(12)
    );

    getDocs(q).then((snap) => {
      const list: Recipe[] = snap.docs
        .filter((d) => d.id !== recipe.id)
        .map((d) => ({
          id: d.id,
          ...(d.data() as any),
        }));
      setRelated(list);
    });
  }, [recipe?.id]);

  // 🔥 내 재료(pantry) 구독 → 재료 보유 여부 체크에 사용
  useEffect(() => {
    if (authLoading) return;
    if (!user) {
      setPantry([]);
      return;
    }

    const col = collection(db, "users", user.uid, "pantry");
    const unsub = onSnapshot(col, (snap) => {
      const items: PantryItem[] = snap.docs.map((d) => ({
        id: d.id,
        ...(d.data() as any),
      }));
      setPantry(items);
    });

    return () => unsub();
  }, [user, authLoading]);

  // 내가 가진 재료 이름 Set (소문자 + trim)
  const pantrySet = useMemo(() => {
    const s = new Set<string>();
    pantry.forEach((p) => {
      const n = (p.name ?? "").trim().toLowerCase();
      if (n) s.add(n);
    });
    return s;
  }, [pantry]);

  // 레시피 재료 배열 (string 통일)
  const ingredientNames: string[] = useMemo(() => {
    if (!recipe?.ingredients) return [];
    return recipe.ingredients
      .map((ing) =>
        typeof ing === "string" ? ing : ing.name
      )
      .map((n) => (n ?? "").trim())
      .filter(Boolean);
  }, [recipe?.ingredients]);

  if (loading) {
    return (
      <View style={styles.center}>
        <ActivityIndicator />
        <Text style={{ marginTop: 8 }}>
          레시피 정보를 불러오는 중…
        </Text>
      </View>
    );
  }

  if (!recipe) {
    return (
      <View style={styles.center}>
        <Text>해당 레시피를 찾을 수 없습니다.</Text>
      </View>
    );
  }

  const heroImage = recipe.imageUrl || recipe.image || "";

  const hasSteps = !!(recipe.steps && recipe.steps.length > 0);

  return (
    <View style={{ flex: 1, backgroundColor: "#fff" }}>
      <AppHeader title={recipe.title || "레시피"} showBack />

      <ScrollView
        contentContainerStyle={{
          paddingHorizontal: 16,
          paddingBottom: 24,
        }}
      >
        {/* 상단 이미지 */}
        <View style={{ marginTop: 12, marginBottom: 16 }}>
          <View
            style={{
              width: "100%",
              borderRadius: 18,
              overflow: "hidden",
              backgroundColor: "#e5e7eb",
            }}
          >
            {heroImage ? (
              <RecipeCardAny
                item={{
                  id: recipe.id,
                  title: recipe.title,
                  imageUrl: heroImage,
                }}
                size={220}
              />
            ) : (
              <View
                style={{
                  height: 200,
                  alignItems: "center",
                  justifyContent: "center",
                }}
              >
                <Text style={{ color: "#6b7280" }}>
                  이미지 없음
                </Text>
              </View>
            )}
          </View>
        </View>

        {/* 기본 정보 + 요리 모드 버튼 */}
        <View style={{ marginBottom: 16 }}>
          <Text style={styles.title}>{recipe.title}</Text>
          <Text style={styles.meta}>
            {recipe.time ? `${recipe.time}분 · ` : ""}
            {recipe.difficulty ?? "난이도 정보 없음"}
          </Text>

          {recipe.tags && recipe.tags.length > 0 && (
            <View
              style={{
                flexDirection: "row",
                flexWrap: "wrap",
                marginTop: 6,
              }}
            >
              {recipe.tags.map((t) => (
                <View key={t} style={styles.tagChip}>
                  <Text style={styles.tagText}>#{t}</Text>
                </View>
              ))}
            </View>
          )}

          {/* 👉 요리 모드 시작 버튼 */}
          {hasSteps && (
            <Pressable
              style={styles.cookBtn}
              onPress={() =>
                router.push(`/recipes/${recipe.id}/cook`)
              }
            >
              <Text style={styles.cookBtnText}>
                🍳 요리 모드 시작
              </Text>
            </Pressable>
          )}
        </View>

        {/* 재료 섹션 – 내 재료 보유 여부 표시 */}
        <View style={{ marginBottom: 18 }}>
          <Text style={styles.sectionTitle}>재료</Text>

          {/* 범례 */}
          <View
            style={{
              flexDirection: "row",
              marginTop: 6,
              marginBottom: 4,
            }}
          >
            <View
              style={{
                flexDirection: "row",
                marginRight: 12,
                alignItems: "center",
              }}
            >
              <Text
                style={{
                  fontSize: 12,
                  color: "#16a34a",
                  marginRight: 4,
                }}
              >
                ●
              </Text>
              <Text style={styles.legendText}>
                보유 재료
              </Text>
            </View>
            <View
              style={{
                flexDirection: "row",
                alignItems: "center",
              }}
            >
              <Text
                style={{
                  fontSize: 12,
                  color: "#9ca3af",
                  marginRight: 4,
                }}
              >
                ●
              </Text>
              <Text style={styles.legendText}>
                없는 재료
              </Text>
            </View>
          </View>

          {ingredientNames.length === 0 ? (
            <Text style={{ color: "#6b7280", marginTop: 4 }}>
              재료 정보가 없습니다.
            </Text>
          ) : (
            <View style={{ marginTop: 4 }}>
              {ingredientNames.map((name, idx) => {
                const key = `${idx}-${name}`;
                const has = pantrySet.has(
                  name.trim().toLowerCase()
                );
                return (
                  <View
                    key={key}
                    style={styles.ingRow}
                  >
                    <View
                      style={[
                        styles.ingDot,
                        {
                          backgroundColor: has
                            ? "#16a34a"
                            : "#d1d5db",
                        },
                      ]}
                    />
                    <Text
                      style={[
                        styles.ingText,
                        has && styles.ingTextOwned,
                      ]}
                    >
                      {name}
                    </Text>
                    <Text
                      style={[
                        styles.ingBadge,
                        has
                          ? styles.ingBadgeOwned
                          : styles.ingBadgeLack,
                      ]}
                    >
                      {has ? "보유중" : "없음"}
                    </Text>
                  </View>
                );
              })}
            </View>
          )}
        </View>

        {/* 조리 단계 */}
        {recipe.steps && recipe.steps.length > 0 && (
          <View style={{ marginBottom: 18 }}>
            <Text style={styles.sectionTitle}>
              조리 단계
            </Text>
            <View style={{ marginTop: 6 }}>
              {recipe.steps.map((s, idx) => (
                <View
                  key={idx}
                  style={{
                    flexDirection: "row",
                    marginBottom: 4,
                  }}
                >
                  <Text
                    style={{
                      marginRight: 6,
                      fontWeight: "700",
                      color: "#4b5563",
                    }}
                  >
                    {idx + 1}.
                  </Text>
                  <Text
                    style={{
                      flex: 1,
                      color: "#111827",
                      lineHeight: 20,
                    }}
                  >
                    {s}
                  </Text>
                </View>
              ))}
            </View>
          </View>
        )}

        {/* 관련 레시피 */}
        {related.length > 0 && (
          <View style={{ marginBottom: 8 }}>
            <Text style={styles.sectionTitle}>
              관련 레시피
            </Text>
            <ScrollView
              horizontal
              showsHorizontalScrollIndicator={false}
              style={{ marginTop: 10 }}
            >
              {related.map((r) => {
                const img = r.imageUrl || r.image || "";
                return (
                  <View
                    key={r.id}
                    style={{ marginRight: 12, width: 140 }}
                  >
                    <RecipeCardAny
                      item={{
                        id: r.id,
                        title: r.title,
                        imageUrl: img,
                      }}
                      size={140}
                    />
                  </View>
                );
              })}
            </ScrollView>
          </View>
        )}
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  center: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
  },
  title: {
    fontSize: 20,
    fontWeight: "800",
  },
  meta: {
    marginTop: 4,
    fontSize: 13,
    color: "#6b7280",
  },
  tagChip: {
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 999,
    backgroundColor: "#eef2ff",
    marginRight: 6,
    marginBottom: 4,
  },
  tagText: {
    fontSize: 11,
    color: "#4f46e5",
    fontWeight: "700",
  },
  sectionTitle: {
    fontSize: 16,
    fontWeight: "700",
  },
  legendText: {
    fontSize: 11,
    color: "#6b7280",
  },

  cookBtn: {
    marginTop: 10,
    alignSelf: "flex-start",
    paddingHorizontal: 14,
    paddingVertical: 8,
    borderRadius: 999,
    backgroundColor: "#0ea5e9",
  },
  cookBtnText: {
    color: "#fff",
    fontWeight: "700",
    fontSize: 13,
  },

  ingRow: {
    flexDirection: "row",
    alignItems: "center",
    paddingVertical: 4,
  },
  ingDot: {
    width: 8,
    height: 8,
    borderRadius: 999,
    marginRight: 8,
  },
  ingText: {
    flex: 1,
    fontSize: 14,
    color: "#111827",
  },
  ingTextOwned: {
    color: "#16a34a",
    fontWeight: "600",
  },
  ingBadge: {
    fontSize: 11,
    paddingHorizontal: 8,
    paddingVertical: 3,
    borderRadius: 999,
    overflow: "hidden",
  },
  ingBadgeOwned: {
    backgroundColor: "#dcfce7",
    color: "#166534",
  },
  ingBadgeLack: {
    backgroundColor: "#fee2e2",
    color: "#b91c1c",
  },
});
