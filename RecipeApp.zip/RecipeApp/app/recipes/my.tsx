// app/recipes/my.tsx
import { useRouter } from "expo-router";
import {
  collection,
  query as fsQuery,
  onSnapshot,
  orderBy,
} from "firebase/firestore";
import React, { useEffect, useMemo, useState } from "react";
import {
  ActivityIndicator,
  Dimensions,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from "react-native";
import AppHeader from "../../components/AppHeader";
import RecipeCard from "../../components/RecipeCard";
import { db } from "../../lib/firebase";

// 레시피 타입
type MyRecipe = {
  id: string;
  title: string;
  description?: string;
  imageUrl?: string;
  image?: string;
  time?: number;
  difficulty?: "easy" | "medium" | "hard" | string;
  ingredients?: { name: string }[];
  tags?: string[];
  createdAt?: any;
};

const { width } = Dimensions.get("window");
const GRID_ITEM_SIZE = width / 2 - 32;

const RecipeCardAny = RecipeCard as any;

type ViewType = "grid" | "list";
type SortType = "latest" | "timeAsc";

export default function MyRecipesScreen() {
  const router = useRouter();

  const [recipes, setRecipes] = useState<MyRecipe[]>([]);
  const [loading, setLoading] = useState(true);

  const [view, setView] = useState<ViewType>("grid");
  const [sort, setSort] = useState<SortType>("latest");

  // 🔥 전역 recipes 컬렉션 구독
  useEffect(() => {
    const q = fsQuery(
      collection(db, "recipes"),
      orderBy("createdAt", "desc")
    );

    const unsub = onSnapshot(
      q,
      (snap) => {
        const items: MyRecipe[] = snap.docs.map((d) => ({
          id: d.id,
          ...(d.data() as any),
        }));
        setRecipes(items);
        setLoading(false);
      },
      (err) => {
        console.error(err);
        setLoading(false);
      }
    );

    return () => unsub();
  }, []);

  // 정렬만 적용
  const sorted = useMemo(() => {
    const list = [...recipes];
    if (sort === "timeAsc") {
      list.sort((a, b) => {
        const ta = a.time ?? 9999;
        const tb = b.time ?? 9999;
        return ta - tb;
      });
    }
    // latest 는 Firestore에서 desc
    return list;
  }, [recipes, sort]);

  function toggleSort() {
    setSort((prev) =>
      prev === "latest" ? "timeAsc" : "latest"
    );
  }

  return (
    <View style={{ flex: 1, backgroundColor: "#fff" }}>
      <AppHeader title="내 레시피" showBack />

      {loading ? (
        <View style={styles.center}>
          <ActivityIndicator />
          <Text style={{ marginTop: 8 }}>
            내 레시피를 불러오는 중…
          </Text>
        </View>
      ) : (
        <ScrollView
          contentContainerStyle={{
            paddingHorizontal: 16,
            paddingBottom: 24,
          }}
        >
          {/* 상단 설명 + 버튼들 */}
          <View style={{ marginTop: 12, marginBottom: 8 }}>
            <Text
              style={{
                fontSize: 14,
                color: "#6b7280",
              }}
            >
              내가 추가한 레시피를 한눈에 모아서 보는 화면입니다.
            </Text>
          </View>

          <View style={styles.topRow}>
            {/* 뷰 전환 */}
            <View style={styles.viewToggle}>
              <Pressable
                onPress={() => setView("grid")}
                style={[
                  styles.viewChip,
                  view === "grid" && styles.viewChipActive,
                ]}
              >
                <Text
                  style={[
                    styles.viewChipText,
                    view === "grid" &&
                      styles.viewChipTextActive,
                  ]}
                >
                  그리드
                </Text>
              </Pressable>
              <Pressable
                onPress={() => setView("list")}
                style={[
                  styles.viewChip,
                  view === "list" && styles.viewChipActive,
                ]}
              >
                <Text
                  style={[
                    styles.viewChipText,
                    view === "list" &&
                      styles.viewChipTextActive,
                  ]}
                >
                  리스트
                </Text>
              </Pressable>
            </View>

            {/* 정렬 */}
            <Pressable
              onPress={toggleSort}
              style={styles.sortBtn}
            >
              <Text style={styles.sortBtnText}>
                정렬:{" "}
                {sort === "latest"
                  ? "최근 추가 순"
                  : "조리시간 오름차순"}
              </Text>
            </Pressable>
          </View>

          {/* 내용 */}
          <View style={{ marginTop: 16 }}>
            {sorted.length === 0 ? (
              <View
                style={{
                  alignItems: "center",
                  marginTop: 40,
                }}
              >
                <Text
                  style={{
                    color: "#6b7280",
                    marginBottom: 12,
                    textAlign: "center",
                  }}
                >
                  아직 등록된 레시피가 없습니다.
                </Text>
                <Pressable
                  onPress={() =>
                    router.push("/recipes/add")
                  }
                  style={styles.addBtn}
                >
                  <Text
                    style={{
                      color: "#fff",
                      fontWeight: "700",
                    }}
                  >
                    첫 레시피 추가하러 가기
                  </Text>
                </Pressable>
              </View>
            ) : view === "grid" ? (
              // 🔳 2열 그리드
              <View style={styles.gridContainer}>
                {sorted.map((r) => {
                  const cardItem = {
                    ...r,
                    imageUrl:
                      r.imageUrl || r.image || "",
                  };
                  return (
                    <View
                      key={r.id}
                      style={styles.gridItem}
                    >
                      <RecipeCardAny
                        item={cardItem}
                        size={GRID_ITEM_SIZE}
                      />
                    </View>
                  );
                })}
              </View>
            ) : (
              // 📋 리스트
              <View style={{ gap: 10 }}>
                {sorted.map((r) => (
                  <Pressable
                    key={r.id}
                    style={styles.listItem}
                    onPress={() =>
                      router.push(`/recipes/${r.id}`)
                    }
                  >
                    <View style={{ flex: 1 }}>
                      <Text
                        style={{
                          fontSize: 16,
                          fontWeight: "700",
                        }}
                        numberOfLines={1}
                      >
                        {r.title}
                      </Text>
                      <Text
                        style={{
                          fontSize: 12,
                          color: "#6b7280",
                          marginTop: 2,
                        }}
                        numberOfLines={1}
                      >
                        {r.time ? `${r.time}분 · ` : ""}
                        {r.difficulty ??
                          "난이도 정보 없음"}
                      </Text>
                    </View>
                    <Text
                      style={{
                        fontSize: 12,
                        color: "#3b82f6",
                        marginLeft: 10,
                      }}
                    >
                      상세보기 →
                    </Text>
                  </Pressable>
                ))}
              </View>
            )}
          </View>
        </ScrollView>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  center: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
  },
  topRow: {
    marginTop: 4,
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
  },
  viewToggle: {
    flexDirection: "row",
    backgroundColor: "#e5e7eb",
    borderRadius: 999,
    padding: 2,
  },
  viewChip: {
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 999,
  },
  viewChipActive: {
    backgroundColor: "#fff",
  },
  viewChipText: {
    fontSize: 11,
    color: "#4b5563",
    fontWeight: "700",
  },
  viewChipTextActive: {
    color: "#111827",
  },
  sortBtn: {
    paddingHorizontal: 10,
    paddingVertical: 6,
    borderRadius: 999,
    borderWidth: StyleSheet.hairlineWidth,
    borderColor: "#d1d5db",
    backgroundColor: "#fff",
  },
  sortBtnText: {
    fontSize: 11,
    fontWeight: "700",
    color: "#111827",
  },

  gridContainer: {
    flexDirection: "row",
    flexWrap: "wrap",
    marginHorizontal: -6,
  },
  gridItem: {
    width: "50%",
    paddingHorizontal: 6,
    marginBottom: 12,
  },

  listItem: {
    flexDirection: "row",
    alignItems: "center",
    padding: 12,
    borderRadius: 12,
    backgroundColor: "#f9fafb",
  },

  addBtn: {
    backgroundColor: "#3b82f6",
    paddingHorizontal: 18,
    paddingVertical: 10,
    borderRadius: 999,
  },
});
