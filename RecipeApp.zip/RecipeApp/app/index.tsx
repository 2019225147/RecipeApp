// app/index.tsx
import { useRouter } from "expo-router";
import {
  collection,
  query as fsQuery,
  limit,
  onSnapshot,
  orderBy,
} from "firebase/firestore";
import React, { useEffect, useState } from "react";
import {
  ActivityIndicator,
  Image,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from "react-native";
import AppHeader from "../components/AppHeader";
import { db, useAuthUser } from "../lib/firebase";

type Recipe = {
  id: string;
  title: string;
  description?: string;
  imageUrl?: string;
  image?: string;
  time?: number;
  difficulty?: "easy" | "medium" | "hard" | string;
  tags?: string[];
};

const RECENT_CARD_WIDTH = 180;
const RECENT_CARD_HEIGHT = 180;

export default function HomeScreen() {
  const router = useRouter();
  const { user } = useAuthUser();

  const [recentRecipes, setRecentRecipes] = useState<Recipe[]>([]);
  const [loading, setLoading] = useState(true);

  // 🔥 Firestore 에서 최근 레시피 6개 가져오기
  useEffect(() => {
    const q = fsQuery(
      collection(db, "recipes"),
      orderBy("createdAt", "desc"),
      limit(6)
    );

    const unsub = onSnapshot(
      q,
      (snap) => {
        const items: Recipe[] = snap.docs.map((d) => ({
          id: d.id,
          ...(d.data() as any),
        }));
        setRecentRecipes(items);
        setLoading(false);
      },
      (err) => {
        console.error(err);
        setLoading(false);
      }
    );

    return () => unsub();
  }, []);

  return (
    <View style={{ flex: 1, backgroundColor: "#f3f4f6" }}>
      <AppHeader title="RecipeApp" showBack={false} />

      <ScrollView
        contentContainerStyle={{
          paddingHorizontal: 16,
          paddingBottom: 24,
        }}
      >
        {/* 상단 Hero 섹션 */}
        <View style={styles.heroCard}>
          <Text style={styles.heroTitle}>
            지금 있는 재료로{"\n"}무엇을 만들 수 있을까요?
          </Text>
          <Text style={styles.heroSub}>
            냉장고 재료를 보관함에 저장하고{"\n"}
            추천 기능으로 바로 만들 수 있는 레시피를 찾아보세요.
          </Text>

          <Pressable
            style={styles.heroButton}
            onPress={() => router.push("/recommend")}
          >
            <Text style={styles.heroButtonText}>재료로 레시피 추천 받기</Text>
          </Pressable>
        </View>

        {/* 빠른 메뉴 */}
        <Text style={styles.sectionTitle}>빠른 메뉴</Text>

        {/* 1행: 레시피 목록 / 재료 기반 추천 / 즐겨찾기 */}
        <View style={styles.quickRow}>
          <QuickButton
            label="레시피 목록 보기"
            desc="그리드/리스트 전환"
            onPress={() => router.push("/recipes")}
          />
          <QuickButton
            label="보유 재료 추천"
            desc="지금 만들 수 있는 요리"
            onPress={() => router.push("/recommend")}
          />
          <QuickButton
            label="즐겨찾기 보기"
            desc="자주 보는 레시피"
            onPress={() => router.push("/favorites")}
          />
        </View>

        {/* 2행: 내 레시피 / 레시피 추가 / 재료 관리 */}
        <View style={{ height: 8 }} />
        <View style={styles.quickRow}>
          <QuickButton
            label="내 레시피 보기"
            desc="내가 등록한 레시피"
            onPress={() => router.push("/recipes/my")}
          />
          <QuickButton
            label="+ 레시피 추가"
            desc="새 레시피 등록"
            onPress={() => router.push("/recipes/add")}
          />
          <QuickButton
            label="재료 관리"
            desc="보관 중인 재료"
            onPress={() => router.push("/pantry")}
          />
        </View>

        {/* 사용자 정보 간단 표기 */}
        <View style={styles.userInfo}>
          <Text style={styles.userInfoText}>
            로그인 상태:{" "}
            {user ? `익명 사용자 (${user.uid.slice(0, 6)}…)` : "로그인 전"}
          </Text>
        </View>

        {/* 최근 추가된 레시피 */}
        <View style={{ marginTop: 8 }}>
          <Text style={styles.sectionTitle}>최근 추가된 레시피</Text>

          {loading ? (
            <View style={styles.centerRow}>
              <ActivityIndicator />
              <Text style={{ marginLeft: 8 }}>불러오는 중…</Text>
            </View>
          ) : recentRecipes.length === 0 ? (
            <Text style={{ color: "#6b7280", marginTop: 8 }}>
              아직 등록된 레시피가 없습니다.{"\n"}
              “+ 레시피 추가” 메뉴에서 첫 레시피를 만들어 보세요.
            </Text>
          ) : (
            <ScrollView
              horizontal
              showsHorizontalScrollIndicator={false}
              contentContainerStyle={{ paddingVertical: 8 }}
            >
              {recentRecipes.map((r) => {
                const img = r.imageUrl || r.image || "";
                return (
                  <Pressable
                    key={r.id}
                    style={styles.recentCard}
                    onPress={() => router.push(`/recipes/${r.id}`)}
                  >
                    {img ? (
                      <Image
                        source={{ uri: img }}
                        style={styles.recentImage}
                        resizeMode="cover"
                      />
                    ) : (
                      <View style={styles.recentImage}>
                        <Text style={{ color: "#9ca3af", fontSize: 12 }}>
                          이미지 없음
                        </Text>
                      </View>
                    )}

                    <View style={{ paddingHorizontal: 8, paddingVertical: 6 }}>
                      <Text
                        numberOfLines={1}
                        style={{
                          fontSize: 13,
                          fontWeight: "700",
                          marginBottom: 2,
                        }}
                      >
                        {r.title ?? "(제목 없음)"}
                      </Text>
                      <Text
                        numberOfLines={1}
                        style={{ fontSize: 11, color: "#6b7280" }}
                      >
                        {r.time ? `${r.time}분 · ` : ""}
                        {r.difficulty ?? "난이도 정보 없음"}
                      </Text>
                    </View>
                  </Pressable>
                );
              })}
            </ScrollView>
          )}
        </View>

        {/* 하단 여백 */}
        <View style={{ height: 16 }} />
      </ScrollView>
    </View>
  );
}

function QuickButton({
  label,
  desc,
  onPress,
}: {
  label: string;
  desc: string;
  onPress: () => void;
}) {
  return (
    <Pressable style={styles.quickBtn} onPress={onPress}>
      <Text style={styles.quickLabel}>{label}</Text>
      <Text style={styles.quickDesc}>{desc}</Text>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  heroCard: {
    marginTop: 12,
    borderRadius: 20,
    padding: 16,
    backgroundColor: "#111827",
  },
  heroTitle: {
    color: "#f9fafb",
    fontSize: 20,
    fontWeight: "800",
    marginBottom: 8,
  },
  heroSub: {
    color: "#e5e7eb",
    fontSize: 12,
    lineHeight: 18,
    marginBottom: 12,
  },
  heroButton: {
    alignSelf: "flex-start",
    backgroundColor: "#3b82f6",
    paddingHorizontal: 14,
    paddingVertical: 8,
    borderRadius: 999,
  },
  heroButtonText: {
    color: "#fff",
    fontWeight: "700",
    fontSize: 13,
  },

  sectionTitle: {
    marginTop: 18,
    marginBottom: 8,
    fontSize: 16,
    fontWeight: "800",
  },

  quickRow: {
    flexDirection: "row",
    justifyContent: "space-between",
  },
  quickBtn: {
    flex: 1,
    backgroundColor: "#ffffff",
    borderRadius: 14,
    paddingHorizontal: 10,
    paddingVertical: 10,
    marginRight: 8,
    shadowColor: "#000",
    shadowOpacity: 0.06,
    shadowOffset: { width: 0, height: 2 },
    shadowRadius: 4,
    elevation: 2,
  },
  quickLabel: {
    fontSize: 13,
    fontWeight: "700",
    marginBottom: 4,
  },
  quickDesc: {
    fontSize: 11,
    color: "#6b7280",
  },

  userInfo: {
    marginTop: 12,
    paddingVertical: 6,
  },
  userInfoText: {
    fontSize: 11,
    color: "#6b7280",
  },

  centerRow: {
    flexDirection: "row",
    alignItems: "center",
    marginTop: 4,
  },

  recentCard: {
    width: RECENT_CARD_WIDTH,
    height: RECENT_CARD_HEIGHT,
    backgroundColor: "#ffffff",
    borderRadius: 18,
    marginRight: 12,
    overflow: "hidden",
    shadowColor: "#000",
    shadowOpacity: 0.08,
    shadowOffset: { width: 0, height: 3 },
    shadowRadius: 6,
    elevation: 3,
  },
  recentImage: {
    width: "100%",
    height: RECENT_CARD_HEIGHT - 60,
    backgroundColor: "#e5e7eb",
    alignItems: "center",
    justifyContent: "center",
  },
});
