// app/add-recipe.tsx
import { addDoc, collection, doc, Timestamp, updateDoc } from 'firebase/firestore';
import React, { useState } from 'react';
import { Alert, Button, ScrollView, Text, TextInput } from 'react-native';
import ImagePickerField from '../components/ImagePickerField';
import { auth, db, ensureAnonLogin } from '../lib/firebase'; // 경로 주의
import { uploadImageAsync } from '../services/storage';

export default function AddRecipeScreen() {
  const [title, setTitle] = useState('');
  const [desc, setDesc] = useState('');
  const [imageLocalUri, setImageLocalUri] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);

  const onSubmit = async () => {
    if (!title.trim()) {
      Alert.alert('필수 입력', '제목을 입력해주세요.');
      return;
    }
    try {
      setSubmitting(true);
      await ensureAnonLogin();
      const uid = auth.currentUser?.uid!;
      const now = Timestamp.now();

      // 1) Firestore 문서 생성(이미지 URL은 일단 null)
      const col = collection(db, 'recipes');
      const docRef = await addDoc(col, {
        title,
        title_lc: title.toLowerCase(),
        description: desc ?? '',
        ingredients: [],
        steps: [],
        imageUrl: null,
        uid,
        createdAt: now,
        updatedAt: now,
      });

      // 2) 이미지가 있으면 업로드 후 URL 저장
      if (imageLocalUri) {
        const url = await uploadImageAsync(
          imageLocalUri,
          `recipeImages/${uid}/${docRef.id}.jpg`
        );
        await updateDoc(doc(db, 'recipes', docRef.id), {
          imageUrl: url,
          updatedAt: Timestamp.now(),
        });
      }

      Alert.alert('완료', '레시피가 등록되었습니다!');
      setTitle('');
      setDesc('');
      setImageLocalUri(null);
    } catch (e: any) {
      Alert.alert('오류', e?.message ?? String(e));
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <ScrollView contentContainerStyle={{ padding: 16, gap: 12 }}>
      <Text style={{ fontSize: 18, fontWeight: '700' }}>레시피 추가</Text>

      <Text>제목</Text>
      <TextInput
        placeholder="예: 토마토 파스타"
        value={title}
        onChangeText={setTitle}
        style={{ borderWidth: 1, borderRadius: 8, padding: 10 }}
      />

      <Text>설명</Text>
      <TextInput
        placeholder="간단한 소개"
        value={desc}
        onChangeText={setDesc}
        multiline
        style={{ borderWidth: 1, borderRadius: 8, padding: 10, minHeight: 80 }}
      />

      <ImagePickerField value={imageLocalUri} onChange={setImageLocalUri} label="대표 이미지" />

      <Button title={submitting ? '등록 중…' : '등록'} onPress={onSubmit} disabled={submitting} />
    </ScrollView>
  );
}
