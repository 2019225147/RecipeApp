// app/favorites/index.tsx
import AppHeader from "@/components/AppHeader";
import { auth, db } from "@/lib/firebase";
import { useRouter } from "expo-router";
import {
  collection,
  getDocs,
  onSnapshot,
  orderBy,
  query,
} from "firebase/firestore";
import React, { useEffect, useMemo, useState } from "react";
import {
  ActivityIndicator,
  FlatList,
  Image,
  Modal,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  View,
} from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";

/* ========== Types ========== */
type Ingredient = { name: string; amount?: number | string; unit?: string };
type RecipeListItem = {
  id: string;
  title: string;
  image?: string;
  time?: number;
  difficulty?: "easy" | "medium" | "hard" | string;
  tags?: string[];
  createdAt?: any;
  description?: string;
  ingredients?: Ingredient[] | string[];
  __scope?: "global" | "mine";
};

type SortBy = "latest" | "name" | "time";
type SortDir = "asc" | "desc";

/* ========== Hooks ========== */
function useRecipesLive() {
  const uid = auth.currentUser?.uid ?? null;
  const [items, setItems] = useState<RecipeListItem[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    setLoading(true);

    const qGlobal = query(
      collection(db, "recipes"),
      orderBy("createdAt", "desc")
    );
    const offGlobal = onSnapshot(qGlobal, (snap) => {
      const list = snap.docs.map((d) => ({
        id: d.id,
        ...(d.data() as any),
        __scope: "global" as const,
      }));
      setItems((prev) => {
        const mineOnly = (prev as any[]).filter((r) => r.__scope === "mine");
        const m = new Map<string, any>();
        [...list, ...mineOnly].forEach((r) => m.set(r.id, r));
        return Array.from(m.values());
      });
      setLoading(false);
    });

    let offMine: undefined | (() => void);
    if (uid) {
      const qMine = query(
        collection(db, "users", uid, "recipes"),
        orderBy("createdAt", "desc")
      );
      offMine = onSnapshot(qMine, (snap) => {
        const mine = snap.docs.map((d) => ({
          id: d.id,
          ...(d.data() as any),
          __scope: "mine" as const,
        }));
        setItems((prev) => {
          const globalOnly = (prev as any[]).filter(
            (r) => r.__scope === "global"
          );
          const m = new Map<string, any>();
          [...globalOnly, ...mine].forEach((r) => m.set(r.id, r));
          return Array.from(m.values());
        });
      });
    }

    return () => {
      offGlobal();
      offMine?.();
    };
  }, [auth.currentUser?.uid]);

  return { items, loading };
}

function useUserFavoritesIds() {
  const uid = auth.currentUser?.uid ?? null;
  const [ids, setIds] = useState<string[]>([]);

  useEffect(() => {
    if (!uid) return;
    (async () => {
      const snaps = await getDocs(collection(db, "users", uid, "favorites"));
      setIds(snaps.docs.map((d) => d.id));
    })();
  }, [uid]);

  const has = (id: string) => ids.includes(id);
  return { ids, has };
}

/* ========== UI 작은 컴포넌트 ========== */
const Pill: React.FC<{ label: string }> = ({ label }) => (
  <View style={styles.pill}>
    <Text style={styles.pillText}>{label}</Text>
  </View>
);

const Chip: React.FC<{
  active?: boolean;
  onPress: () => void;
  children: React.ReactNode;
}> = ({ active, onPress, children }) => (
  <Pressable
    onPress={onPress}
    style={[
      styles.chip,
      active ? styles.chipActive : styles.chipInactive,
    ]}
  >
    <Text
      style={[
        styles.chipText,
        active ? styles.chipTextActive : styles.chipTextInactive,
      ]}
    >
      {children}
    </Text>
  </Pressable>
);

/**
 * 즐겨찾기 카드
 * - grid / list 공통으로 사용
 * - 텍스트 잘림 방지를 위해 여유 있는 padding과 줄 수 설정
 */
const Card: React.FC<{
  item: RecipeListItem;
  onPress: () => void;
  variant: "grid" | "list";
}> = ({ item, onPress, variant }) => {
  const imageHeight = variant === "grid" ? 120 : 140;

  return (
    <Pressable
      onPress={onPress}
      style={styles.card}
    >
      {item.image ? (
        <Image
          source={{ uri: item.image }}
          style={{ width: "100%", height: imageHeight }}
          resizeMode="cover"
        />
      ) : (
        <View
          style={[
            styles.cardImagePlaceholder,
            { height: imageHeight },
          ]}
        >
          <Text style={{ color: "#98A2B3", fontSize: 12 }}>
            이미지 없음
          </Text>
        </View>
      )}

      <View style={styles.cardContent}>
        {/* 제목: 2줄까지 허용 (잘려 보이지 않게) */}
        <Text
          numberOfLines={2}
          style={styles.cardTitle}
        >
          {item.title || "제목 없는 레시피"}
        </Text>

        {/* 설명: 그리드 2줄, 리스트 3줄 정도만 보여주기 */}
        {item.description ? (
          <Text
            numberOfLines={variant === "grid" ? 2 : 3}
            style={styles.cardDescription}
          >
            {item.description}
          </Text>
        ) : null}

        <View style={styles.cardMetaRow}>
          {!!item.time && <Pill label={`⏱️ ${item.time}분`} />}
          {!!item.difficulty && <Pill label={`📈 ${item.difficulty}`} />}
          {Array.isArray(item.ingredients) &&
          (item.ingredients as any)?.length ? (
            <Pill label={`🧺 ${(item.ingredients as any).length}개 재료`} />
          ) : null}
        </View>

        {/* 태그: 1줄로만, ... 처리 */}
        <Text
          style={styles.cardTags}
          numberOfLines={1}
        >
          {(item.tags || [])
            .slice(0, 3)
            .map((t) => `#${t}`)
            .join(" ")}
        </Text>
      </View>
    </Pressable>
  );
};

/* ========== Screen ========== */
export default function FavoritesScreen() {
  const router = useRouter();
  const { items, loading } = useRecipesLive();
  const { has } = useUserFavoritesIds();

  const favItems = useMemo(
    () => items.filter((r) => has(r.id)),
    [items, has]
  );

  const [view, setView] = useState<"grid" | "list">("grid");
  const [q, setQ] = useState("");

  const [sortBy, setSortBy] = useState<SortBy>("latest");
  const [sortDir, setSortDir] = useState<SortDir>("desc");
  const [difficulty, setDifficulty] =
    useState<"all" | "easy" | "medium" | "hard">("all");
  const [timeMax, setTimeMax] = useState<"all" | 10 | 20 | 30>("all");
  const [tagSel, setTagSel] = useState<string[]>([]);

  const allTags = useMemo(() => {
    const acc = new Set<string>();
    favItems.forEach((r) => (r.tags || []).forEach((t) => acc.add(t)));
    return Array.from(acc).sort();
  }, [favItems]);

  const [sheetOpen, setSheetOpen] = useState(false);
  const [tmpSortBy, setTmpSortBy] = useState(sortBy);
  const [tmpSortDir, setTmpSortDir] = useState(sortDir);
  const [tmpDifficulty, setTmpDifficulty] = useState(difficulty);
  const [tmpTimeMax, setTmpTimeMax] = useState(timeMax);
  const [tmpTagSel, setTmpTagSel] = useState<string[]>(tagSel);

  function openSheet() {
    setTmpSortBy(sortBy);
    setTmpSortDir(sortDir);
    setTmpDifficulty(difficulty);
    setTmpTimeMax(timeMax);
    setTmpTagSel(tagSel);
    setSheetOpen(true);
  }
  function applySheet() {
    setSortBy(tmpSortBy);
    setSortDir(tmpSortDir);
    setDifficulty(tmpDifficulty);
    setTimeMax(tmpTimeMax);
    setTagSel(tmpTagSel);
    setSheetOpen(false);
  }
  function resetSheet() {
    setTmpSortBy("latest");
    setTmpSortDir("desc");
    setTmpDifficulty("all");
    setTmpTimeMax("all");
    setTmpTagSel([]);
  }

  const appliedCount = useMemo(() => {
    let c = 0;
    if (difficulty !== "all") c++;
    if (timeMax !== "all") c++;
    if (tagSel.length) c++;
    if (!(sortBy === "latest" && sortDir === "desc")) c++;
    return c;
  }, [difficulty, timeMax, tagSel, sortBy, sortDir]);

  function buildComparator() {
    return (a: RecipeListItem, b: RecipeListItem) => {
      let primary = 0;

      if (sortBy === "name") {
        const A = (a.title || "").toLowerCase();
        const B = (b.title || "").toLowerCase();
        primary = A.localeCompare(B);
        if (sortDir === "desc") primary = -primary;
      } else if (sortBy === "time") {
        const A = a.time || 0;
        const B = b.time || 0;
        primary = A - B;
        if (sortDir === "desc") primary = -primary;
      } else {
        const A = (a.createdAt as any)?.toMillis?.() ?? 0;
        const B = (b.createdAt as any)?.toMillis?.() ?? 0;
        primary = A - B;
        if (sortDir === "desc") primary = -primary;
      }

      if (primary !== 0) return primary;
      return (a.title || "").localeCompare(b.title || "");
    };
  }

  // 정렬 규칙 보정
  useEffect(() => {
    if (sortBy === "name" && sortDir === "desc") setSortDir("asc");
    if ((sortBy === "time" || sortBy === "latest") && sortDir === "asc")
      setSortDir("desc");
  }, [sortBy, sortDir]);

  const filtered = useMemo(() => {
    let list = [...favItems];

    if (difficulty !== "all")
      list = list.filter(
        (r) => (r.difficulty || "").toLowerCase() === difficulty
      );
    if (timeMax !== "all")
      list = list.filter((r) => (r.time || 0) <= timeMax);
    if (tagSel.length)
      list = list.filter((r) =>
        tagSel.every((t) => (r.tags || []).includes(t))
      );

    const s = q.trim().toLowerCase();
    if (s) {
      list = list.filter((r) => {
        const hay = [r.title || "", r.description || "", ...(r.tags || [])]
          .join(" ")
          .toLowerCase();
        return hay.includes(s);
      });
    }

    list.sort(buildComparator());
    return list;
  }, [favItems, difficulty, timeMax, tagSel, q, sortBy, sortDir]);

  if (loading) {
    return (
      <SafeAreaView style={styles.safeArea}>
        <AppHeader title="즐겨찾기" showBack />
        <View style={styles.center}>
          <ActivityIndicator />
          <Text style={styles.loadingText}>불러오는 중…</Text>
        </View>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.safeArea}>
      {/* 헤더 */}
      <AppHeader
        title="즐겨찾기"
        showBack
        rightSlot={
          <Pressable
            onPress={() =>
              setView((v) => (v === "grid" ? "list" : "grid"))
            }
            style={styles.viewToggleBtn}
          >
            <Text style={styles.viewToggleText}>
              {view === "grid" ? "리스트" : "그리드"}
            </Text>
          </Pressable>
        }
      />

      {/* 검색 + 필터 버튼 */}
      <View style={styles.searchContainer}>
        <View style={styles.searchBox}>
          <TextInput
            placeholder="검색 (제목/설명/태그)"
            value={q}
            onChangeText={setQ}
            style={styles.searchInput}
          />
        </View>

        <View style={{ flexDirection: "row", justifyContent: "flex-end" }}>
          <Pressable
            onPress={openSheet}
            style={styles.filterBtn}
          >
            <Text style={styles.filterBtnText}>필터·정렬</Text>
            {appliedCount > 0 && (
              <View style={styles.filterBadge}>
                <Text style={styles.filterBadgeText}>{appliedCount}</Text>
              </View>
            )}
          </Pressable>
        </View>
      </View>

      {/* 본문 리스트 */}
      {filtered.length === 0 ? (
        <View style={styles.emptyContainer}>
          <Text style={styles.emptyText}>
            즐겨찾기한 레시피가 없어요.
          </Text>
        </View>
      ) : (
        <FlatList
          key={`fav-${view}`}
          numColumns={view === "grid" ? 2 : 1}
          columnWrapperStyle={
            view === "grid" ? { gap: 12 } : undefined
          }
          contentContainerStyle={styles.listContent}
          data={filtered}
          keyExtractor={(it) => it.id}
          renderItem={({ item }) => (
            <View
              style={{
                flex: 1,
                marginBottom: 12,
              }}
            >
              <Card
                item={item}
                onPress={() => router.push(`/recipes/${item.id}`)}
                variant={view}
              />
            </View>
          )}
        />
      )}

      {/* 바텀시트 (필터/정렬) */}
      <Modal
        visible={sheetOpen}
        animationType="slide"
        transparent
        onRequestClose={() => setSheetOpen(false)}
      >
        <Pressable
          onPress={() => setSheetOpen(false)}
          style={styles.sheetOverlay}
        />
        <View style={styles.sheetContainer}>
          <View style={styles.sheetHandleWrapper}>
            <View style={styles.sheetHandle} />
          </View>

          <ScrollView contentContainerStyle={{ paddingBottom: 12 }}>
            <Text style={styles.sheetSectionTitle}>정렬</Text>
            <View style={styles.chipRow}>
              <Chip
                active={tmpSortBy === "latest"}
                onPress={() => setTmpSortBy("latest")}
              >
                최신
              </Chip>
              <Chip
                active={tmpSortBy === "name"}
                onPress={() => setTmpSortBy("name")}
              >
                이름
              </Chip>
              <Chip
                active={tmpSortBy === "time"}
                onPress={() => setTmpSortBy("time")}
              >
                시간
              </Chip>
              <Chip
                active={tmpSortDir === "asc"}
                onPress={() => setTmpSortDir("asc")}
              >
                오름 ↑
              </Chip>
              <Chip
                active={tmpSortDir === "desc"}
                onPress={() => setTmpSortDir("desc")}
              >
                내림 ↓
              </Chip>
            </View>

            <Text style={styles.sheetSectionTitle}>난이도</Text>
            <View style={styles.chipRow}>
              {(["all", "easy", "medium", "hard"] as const).map((d) => (
                <Chip
                  key={d}
                  active={tmpDifficulty === d}
                  onPress={() => setTmpDifficulty(d)}
                >
                  {d === "all" ? "전체" : d}
                </Chip>
              ))}
            </View>

            <Text style={styles.sheetSectionTitle}>조리 시간</Text>
            <View style={styles.chipRow}>
              {(["all", 10, 20, 30] as const).map((t) => (
                <Chip
                  key={String(t)}
                  active={tmpTimeMax === t}
                  onPress={() => setTmpTimeMax(t)}
                >
                  {t === "all" ? "전체" : `≤ ${t}분`}
                </Chip>
              ))}
            </View>

            {allTags.length > 0 && (
              <>
                <Text style={styles.sheetSectionTitle}>태그</Text>
                <View style={styles.chipRow}>
                  {allTags.map((t) => {
                    const active = tmpTagSel.includes(t);
                    return (
                      <Chip
                        key={t}
                        active={active}
                        onPress={() =>
                          setTmpTagSel((prev) =>
                            active
                              ? prev.filter((x) => x !== t)
                              : [...prev, t]
                          )
                        }
                      >
                        #{t}
                      </Chip>
                    );
                  })}
                </View>
              </>
            )}
          </ScrollView>

          <View style={styles.sheetFooterRow}>
            <Pressable
              onPress={resetSheet}
              style={styles.sheetResetBtn}
            >
              <Text style={styles.sheetResetText}>초기화</Text>
            </Pressable>
            <Pressable
              onPress={applySheet}
              style={styles.sheetApplyBtn}
            >
              <Text style={styles.sheetApplyText}>적용하기</Text>
            </Pressable>
          </View>
        </View>
      </Modal>
    </SafeAreaView>
  );
}

/* ========== Styles ========== */
const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: "#F8FAFC",
  },
  center: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
  },
  loadingText: {
    marginTop: 8,
    color: "#667085",
  },

  // 검색 영역
  searchContainer: {
    padding: 16,
    gap: 10,
    backgroundColor: "#ffffff",
  },
  searchBox: {
    backgroundColor: "#F2F4F7",
    borderRadius: 12,
    paddingHorizontal: 12,
    paddingVertical: 8,
  },
  searchInput: {
    fontSize: 14,
  },

  // 필터 버튼
  filterBtn: {
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: 10,
    backgroundColor: "#3538CD",
    flexDirection: "row",
    alignItems: "center",
  },
  filterBtnText: {
    color: "#ffffff",
    fontWeight: "800",
  },
  filterBadge: {
    marginLeft: 6,
    backgroundColor: "#ffffff",
    borderRadius: 999,
    paddingHorizontal: 6,
    paddingVertical: 2,
  },
  filterBadgeText: {
    color: "#3538CD",
    fontWeight: "800",
    fontSize: 12,
  },

  // 보기 전환 버튼
  viewToggleBtn: {
    paddingHorizontal: 8,
    paddingVertical: 6,
    borderRadius: 8,
    backgroundColor: "#EEF2FF",
  },
  viewToggleText: {
    color: "#3538CD",
    fontWeight: "700",
    fontSize: 12,
  },

  // 리스트
  listContent: {
    paddingHorizontal: 16,
    paddingTop: 12,
    paddingBottom: 24,
  },

  emptyContainer: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
    padding: 24,
  },
  emptyText: {
    color: "#667085",
  },

  // 카드
  card: {
    backgroundColor: "#ffffff",
    borderRadius: 16,
    overflow: "hidden",
    shadowColor: "#000",
    shadowOpacity: 0.06,
    shadowRadius: 8,
    shadowOffset: { width: 0, height: 2 },
    flex: 1,
  },
  cardImagePlaceholder: {
    width: "100%",
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: "#F2F4F7",
  },
  cardContent: {
    paddingHorizontal: 12,
    paddingVertical: 10,
  },
  cardTitle: {
    fontWeight: "800",
    fontSize: 14,
    color: "#111827",
    marginBottom: 4,
  },
  cardDescription: {
    fontSize: 12,
    color: "#667085",
    lineHeight: 17,
    marginBottom: 6,
  },
  cardMetaRow: {
    flexDirection: "row",
    flexWrap: "wrap",
    gap: 6,
    alignItems: "center",
    marginBottom: 4,
  },
  cardTags: {
    fontSize: 11,
    color: "#98A2B3",
  },

  // 작은 Pill
  pill: {
    paddingHorizontal: 8,
    paddingVertical: 4,
    backgroundColor: "#F2F4F7",
    borderRadius: 999,
  },
  pillText: {
    fontSize: 12,
    fontWeight: "600",
    color: "#344054",
  },

  // Chip
  chip: {
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: 999,
    marginRight: 8,
    marginBottom: 8,
  },
  chipActive: {
    backgroundColor: "#3538CD",
  },
  chipInactive: {
    backgroundColor: "#EEF2FF",
  },
  chipText: {
    fontWeight: "700",
  },
  chipTextActive: {
    color: "#ffffff",
  },
  chipTextInactive: {
    color: "#3538CD",
  },

  chipRow: {
    flexDirection: "row",
    flexWrap: "wrap",
  },

  // 바텀시트
  sheetOverlay: {
    flex: 1,
    backgroundColor: "rgba(0,0,0,0.35)",
  },
  sheetContainer: {
    backgroundColor: "#ffffff",
    paddingTop: 14,
    paddingHorizontal: 16,
    paddingBottom: 16,
    borderTopLeftRadius: 16,
    borderTopRightRadius: 16,
    maxHeight: "75%",
  },
  sheetHandleWrapper: {
    alignItems: "center",
    marginBottom: 10,
  },
  sheetHandle: {
    width: 40,
    height: 4,
    backgroundColor: "#E5E7EB",
    borderRadius: 999,
  },
  sheetSectionTitle: {
    fontSize: 14,
    fontWeight: "800",
    marginVertical: 8,
  },
  sheetFooterRow: {
    flexDirection: "row",
    gap: 10,
    marginTop: 8,
  },
  sheetResetBtn: {
    flex: 1,
    backgroundColor: "#EEF2FF",
    padding: 12,
    borderRadius: 10,
    alignItems: "center",
  },
  sheetResetText: {
    color: "#3538CD",
    fontWeight: "800",
  },
  sheetApplyBtn: {
    flex: 2,
    backgroundColor: "#3538CD",
    padding: 12,
    borderRadius: 10,
    alignItems: "center",
  },
  sheetApplyText: {
    color: "#ffffff",
    fontWeight: "800",
  },
});
