// app/recommend/index.tsx
import {
  collection,
  doc,
  onSnapshot,
  query,
  serverTimestamp,
  setDoc,
} from "firebase/firestore";
import React, { useEffect, useMemo, useState } from "react";
import {
  ActivityIndicator,
  Alert,
  Dimensions,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from "react-native";

// ✅ 상대경로(alias 완전 우회)
import AppHeader from "../../components/AppHeader";
import RecipeCard from "../../components/RecipeCard";
import { db, useAuthUser } from "../../lib/firebase";
import { scoreRecipesByPantry } from "../../services/recommend";

// ✅ TS/props 예민함 완전 우회
const RecipeCardAny = RecipeCard as any;

export default function RecommendScreen() {
  const { user, loading: authLoading } = useAuthUser();

  const [recipes, setRecipes] = useState<any[]>([]);
  const [pantry, setPantry] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  const [view, setView] = useState<"grid" | "list">("grid");
  const [adding, setAdding] = useState<Record<string, boolean>>({}); // recipe id 별 추가중 표시

  // ✅ 카드 크기 계산 (숫자 폭 고정)
  const screenW = Dimensions.get("window").width;
  const rawGridSize = Math.floor((screenW - 16 * 2 - 12) / 2);
  const gridSize = Math.min(rawGridSize, 220); // ✅ 웹에서 너무 커지지 않게 상한(선택)
  const listSize = Math.min(screenW - 16 * 2, 420); // ✅ 리스트도 상한(선택)

  // 1) recipes 구독
  useEffect(() => {
    const qy = query(collection(db, "recipes"));
    const unsub = onSnapshot(
      qy,
      (snap) => {
        const items = snap.docs.map((d) => ({
          id: d.id,
          ...(d.data() as any),
        }));
        setRecipes(items);
      },
      (err) => console.error(err)
    );
    return unsub;
  }, []);

  // 2) pantry 구독
  useEffect(() => {
    if (authLoading) return;
    if (!user?.uid) {
      setLoading(false);
      return;
    }

    const qy = query(collection(db, "users", user.uid, "pantry"));
    const unsub = onSnapshot(
      qy,
      (snap) => {
        const items = snap.docs.map((d) => ({
          id: d.id,
          ...(d.data() as any),
        }));
        setPantry(items);
        setLoading(false);
      },
      (err) => {
        console.error(err);
        setLoading(false);
      }
    );

    return unsub;
  }, [authLoading, user?.uid]);

  // 3) 점수화 추천
  const scored = useMemo(() => {
    if (!recipes.length) return [];
    return scoreRecipesByPantry(pantry, recipes);
  }, [pantry, recipes]);

  const topPicks = scored.filter((r: any) => r.matchRate >= 0.6).slice(0, 10);
  const others = scored.filter((r: any) => r.matchRate < 0.6).slice(0, 20);

  // RecipeCard item 스키마 보정(imageUrl/image 호환)
  function toCardItem(r: any) {
    return {
      ...r,
      imageUrl: r.imageUrl ?? r.image ?? "",
    };
  }

  // ✅ 부족 재료를 pantry에 “한 번에” 추가
  async function addMissingToPantry(recipeId: string, missing: string[]) {
    if (!user?.uid) {
      Alert.alert("로그인이 필요합니다");
      return;
    }
    if (!missing?.length) return;

    setAdding((prev) => ({ ...prev, [recipeId]: true }));

    try {
      // 현재 pantry 이름 Set (중복 방지)
      const existing = new Set(
        pantry.map((p: any) => String(p.name ?? "").trim())
      );

      const tasks = missing
        .map((name) => String(name).trim())
        .filter(Boolean)
        .filter((name) => !existing.has(name))
        .map((name) => {
          const ref = doc(collection(db, "users", user.uid, "pantry"));
          return setDoc(
            ref,
            {
              name,
              amount: "",
              unit: "",
              addedAt: serverTimestamp(),
            },
            { merge: true }
          );
        });

      await Promise.all(tasks);

      Alert.alert("추가 완료", "부족 재료를 pantry에 추가했어요!");
    } catch (e: any) {
      Alert.alert("추가 실패", String(e?.message ?? e));
    } finally {
      setAdding((prev) => ({ ...prev, [recipeId]: false }));
    }
  }

  if (loading) {
    return (
      <View style={styles.center}>
        <ActivityIndicator />
      </View>
    );
  }

  const Toggle = () => (
    <View style={styles.toggleRow}>
      <Pressable
        onPress={() => setView("grid")}
        style={view === "grid" ? styles.toggleBtnActive : styles.toggleBtn}
      >
        <Text
          style={view === "grid" ? styles.toggleTextActive : styles.toggleText}
        >
          그리드
        </Text>
      </Pressable>
      <Pressable
        onPress={() => setView("list")}
        style={view === "list" ? styles.toggleBtnActive : styles.toggleBtn}
      >
        <Text
          style={view === "list" ? styles.toggleTextActive : styles.toggleText}
        >
          리스트
        </Text>
      </Pressable>
    </View>
  );

  // ✅ 공통 렌더 함수 (숫자 폭 배치 + 부족재료 버튼)
  function renderCards(list: any[], subtleBadge?: boolean) {
    return (
      <View style={styles.wrap}>
        {list.map((r: any) => {
          const percent = Math.round(r.matchRate * 100);
          const itemW = view === "grid" ? gridSize : listSize;
          const missing: string[] = r.missing ?? [];
          const hasMissing = missing.length > 0;

          return (
            <View key={r.id} style={{ width: itemW, marginBottom: 12 }}>
              <RecipeCardAny
                item={toCardItem(r)}
                size={itemW}
                topLeftBadges={[
                  {
                    text: `매칭 ${percent}%`,
                    tone: subtleBadge ? "light" : "dark",
                  },
                  {
                    text: `${r.matchCount}/${r.totalNeed}`,
                    tone: subtleBadge ? "light" : "dark",
                  },
                ]}
              />

              {/* 부족 재료 텍스트 */}
              <MissingText r={r} subtle={subtleBadge} />

              {/* ✅ 부족 재료 → pantry 바로 추가 버튼 */}
              {hasMissing && (
                <Pressable
                  onPress={() => addMissingToPantry(r.id, missing)}
                  disabled={!!adding[r.id]}
                  style={[
                    styles.addBtn,
                    subtleBadge && styles.addBtnSubtle,
                    !!adding[r.id] && { opacity: 0.6 },
                  ]}
                >
                  <Text
                    style={[
                      styles.addBtnText,
                      subtleBadge && styles.addBtnTextSubtle,
                    ]}
                  >
                    {adding[r.id]
                      ? "추가 중..."
                      : `부족 재료 pantry에 추가 (${missing.length}개)`}
                  </Text>
                </Pressable>
              )}
            </View>
          );
        })}
      </View>
    );
  }

  return (
    <ScrollView contentContainerStyle={styles.container}>
      <AppHeader title="추천" />

      <Toggle />

      {/* Top Picks */}
      <Text style={styles.sectionTitle}>지금 만들 수 있는 레시피</Text>
      {topPicks.length === 0 ? (
        <View style={styles.emptyBox}>
          <Text style={{ color: "#6b7280" }}>
            팬트리 재료와 매칭되는 레시피가 아직 없어요 😢
          </Text>
          <Text style={{ color: "#9ca3af", marginTop: 6 }}>
            pantry에 재료를 더 추가해보세요!
          </Text>
        </View>
      ) : (
        renderCards(topPicks)
      )}

      {/* Others */}
      <Text style={styles.sectionTitle}>재료가 조금 부족해요</Text>
      {renderCards(others, true)}

      <View style={{ height: 24 }} />
    </ScrollView>
  );
}

// 부족 재료 표시
function MissingText({ r, subtle }: { r: any; subtle?: boolean }) {
  const preview = (r.missing ?? []).slice(0, 3).join(", ");
  if (!preview) return null;

  return (
    <Text
      style={[styles.missingText, subtle && { color: "#6b7280" }]}
      numberOfLines={1}
    >
      부족: {preview}
      {(r.missing?.length ?? 0) > 3 ? " ..." : ""}
    </Text>
  );
}

const styles = StyleSheet.create({
  container: { padding: 16 },
  center: { flex: 1, alignItems: "center", justifyContent: "center" },

  toggleRow: {
    flexDirection: "row",
    marginTop: 10,
    marginBottom: 6,
  },
  toggleBtn: {
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: 999,
    backgroundColor: "#f3f4f6",
    marginRight: 8,
  },
  toggleBtnActive: {
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: 999,
    backgroundColor: "#111827",
    marginRight: 8,
  },
  toggleText: { fontWeight: "800", color: "#111827", fontSize: 12 },
  toggleTextActive: { fontWeight: "800", color: "#fff", fontSize: 12 },

  sectionTitle: {
    fontSize: 16,
    fontWeight: "800",
    marginTop: 14,
    marginBottom: 8,
  },

  emptyBox: {
    backgroundColor: "#f9fafb",
    borderRadius: 12,
    padding: 14,
    borderWidth: StyleSheet.hairlineWidth,
    borderColor: "#e5e7eb",
    marginBottom: 8,
  },

  // flexWrap이지만 “아이템 폭이 숫자”라 웹에서 안정적
  wrap: {
    flexDirection: "row",
    flexWrap: "wrap",
    justifyContent: "space-between",
  },

  missingText: {
    marginTop: 6,
    fontSize: 12,
    fontWeight: "700",
    color: "#334155",
  },

  addBtn: {
    marginTop: 6,
    backgroundColor: "#111827",
    paddingVertical: 8,
    borderRadius: 10,
    alignItems: "center",
  },
  addBtnSubtle: {
    backgroundColor: "#374151",
  },
  addBtnText: {
    color: "#fff",
    fontWeight: "800",
    fontSize: 12,
  },
  addBtnTextSubtle: {
    color: "#fff",
  },
});
