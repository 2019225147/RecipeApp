// app/dev/seed.tsx
import type { Recipe } from "@/constants/types";
import { db, ensureAnonLogin } from "@/lib/firebase";
import { collection, doc, setDoc } from "firebase/firestore";
import React, { useState } from "react";
import { Alert, Pressable, ScrollView, Text, View } from "react-native";

// 로컬 JSON
const BASE: Recipe[] = require("@/assets/data/recipes.json");

function normalizeId(s: string) {
  return (
    s?.toLowerCase()?.replace(/\s+/g, "-")?.replace(/[^a-z0-9\-]/g, "")?.slice(0, 40) ||
    String(Date.now())
  );
}

export default function SeedScreen() {
  const [running, setRunning] = useState(false);

  const onSeed = async () => {
    if (running) return;
    setRunning(true);

    try {
      const uid = await ensureAnonLogin();
      console.log("Seeding as UID:", uid);

      if (!Array.isArray(BASE) || BASE.length === 0) {
        Alert.alert("오류", "recipes.json 파일이 비어있습니다.");
        return;
      }

      const colRef = collection(db, "recipes");

      for (const item of BASE) {
        const id = (item as any).id ? String((item as any).id) : normalizeId(item.title);
        const data: Omit<Recipe, "id"> = {
          title: item.title,
          ingredients: item.ingredients,
          time: item.time,
          difficulty: item.difficulty as Recipe["difficulty"],
          image: item.image ?? "",
          ...(item as any).steps ? { steps: (item as any).steps } : {},
        };

        await setDoc(doc(colRef, id), data, { merge: true });
      }

      Alert.alert("✅ 완료", `공용 레시피 ${BASE.length}건 업로드 완료!`);
    } catch (e: any) {
      console.error("SEED ERROR:", e);
      Alert.alert("업로드 실패", String(e?.message ?? e));
    } finally {
      setRunning(false);
    }
  };

  return (
    <ScrollView contentContainerStyle={{ padding: 16 }}>
      <Text style={{ fontSize: 20, fontWeight: "700" }}>공용 레시피 시드 업로드</Text>
      <View style={{ height: 8 }} />
      <Text style={{ opacity: 0.8 }}>
        이 버튼은 한 번만 실행하세요. /recipes 컬렉션에 기본 레시피를 업로드합니다.
      </Text>

      <View style={{ height: 12 }} />
      <Pressable
        onPress={onSeed}
        style={{
          backgroundColor: running ? "#9CA3AF" : "#10B981",
          padding: 14,
          borderRadius: 12,
          alignItems: "center",
        }}
      >
        <Text style={{ color: "#fff", fontWeight: "700" }}>
          {running ? "업로드 중..." : "업로드 실행"}
        </Text>
      </Pressable>

      <View style={{ height: 12 }} />
      <Text style={{ fontSize: 12, color: "#6B7280" }}>
        * 업로드 후 Firestore 콘솔에서 recipes 컬렉션이 생성되었는지 확인하세요.
        {"\n"}* 완료되면 Firestore 규칙에서 /recipes 쓰기를 다시 비활성화하세요.
      </Text>
    </ScrollView>
  );
}
