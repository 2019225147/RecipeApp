// app/_layout.tsx
import { useAuthReady } from '@/hooks/useAuthReady';
import { Slot } from 'expo-router';
import React from 'react';
import { ActivityIndicator, View } from 'react-native';

export default function RootLayout() {
  const ready = useAuthReady();

  if (!ready) {
    return (
      <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center' }}>
        <ActivityIndicator />
      </View>
    );
  }

  return <Slot />;
}
